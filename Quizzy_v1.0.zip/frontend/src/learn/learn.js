// src/learn/Learn.js

import React, { useState } from 'react';
import * as aiQuizService from '../services/aiQuizService';
import { logAiEvent } from '../services/loggingService'; // <-- NEW IMPORT
import Button from '../components/Button';
import './Learn.css';

const Learn = () => {
    const [topic, setTopic] = useState('');
    const [moduleData, setModuleData] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [answers, setAnswers] = useState({});
    const [currentTopic, setCurrentTopic] = useState('');

    const handleGenerate = async (e) => {
        e.preventDefault();
        if (!topic) {
            setError('Please enter a topic to learn about.');
            return;
        }
        setIsLoading(true);
        setError('');
        setModuleData(null);
        setAnswers({});

        try {
            const data = await aiQuizService.generateLearningModule({
                topic,
                model: 'phi4-mini:3.8b', // <-- NEW MODEL
            });
            
            // --- NEW: Log the successful generation event ---
            logAiEvent('Learn Module', topic);

            setModuleData(data);
            setCurrentTopic(topic);
        } catch (err) {
            setError(err.message || 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleAnswerSelect = (questionIndex, selectedOptionIndex) => {
        setAnswers(prev => ({
            ...prev,
            [questionIndex]: selectedOptionIndex
        }));
    };

    const handleNextLesson = async () => {
        if (!currentTopic) {
            setError('No current topic to generate next lesson for.');
            return;
        }

        setIsLoading(true);
        setError('');
        setAnswers({});

        try {
            const data = await aiQuizService.generateLearningModule({
                topic: currentTopic,
                model: 'phi4-mini:3.8b', // <-- NEW MODEL
            });
            
            // Log the next lesson generation event
            logAiEvent('Learn Module - Next Lesson', currentTopic);

            setModuleData(data);
        } catch (err) {
            setError(err.message || 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    const renderContentBlock = (block, index) => {
        if (block.type === 'paragraph') {
            return <p key={index}>{block.text}</p>;
        }

        if (block.type === 'question') {
            const questionIndex = index;
            const userAnswer = answers[questionIndex];
            const hasAnswered = userAnswer !== undefined;
            const isCorrect = hasAnswered && userAnswer === block.correctOption;

            return (
                <div key={index} className="question-block">
                    <h4>Knowledge Check:</h4>
                    <p><strong>{block.text}</strong></p>
                    <ul className="options-list">
                        {block.options.map((option, optIndex) => {
                            let btnClass = 'option-button';
                            if (hasAnswered) {
                                if (optIndex === block.correctOption) {
                                    btnClass += ' correct';
                                } else if (optIndex === userAnswer) {
                                    btnClass += ' incorrect';
                                }
                            }
                            return (
                                <li key={optIndex}>
                                    <button
                                        className={btnClass}
                                        onClick={() => handleAnswerSelect(questionIndex, optIndex)}
                                        disabled={hasAnswered}
                                    >
                                        {option}
                                    </button>
                                </li>
                            );
                        })}
                    </ul>
                    {hasAnswered && (
                        <div className={`explanation ${isCorrect ? 'correct' : 'incorrect'}`}>
                            {block.explanation}
                        </div>
                    )}
                </div>
            );
        }
        return null;
    };

    return (
        <div className="learn-container">
            <div className="learn-form-card">
                <h1>Interactive Learning</h1>
                <p>Enter any topic you want to learn about, and our AI Tutor will generate a mini-lesson with knowledge checks for you.</p>
                <form onSubmit={handleGenerate} className="learn-form">
                    <input
                        type="text"
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        placeholder="e.g., The French Revolution, How Computers Work, etc."
                        disabled={isLoading}
                    />
                    <Button type="submit" variant="primary" disabled={isLoading}>
                        Generate Lesson
                    </Button>
                </form>
            </div>

            {isLoading && (
                <div className="loading-container">
                    <div className="spinner"></div>
                    <p className="loading-text">Your AI Tutor is preparing the lesson... This may take a minute.</p>
                </div>
            )}

            {error && !isLoading && (
                 <div className="error-container">
                    <p className="error-message">{error}</p>
                 </div>
            )}
            
            {moduleData && !isLoading && (
                <div className="lesson-card">
                    <h2>{moduleData.title}</h2>
                    <div className="lesson-content">
                        {moduleData.content.map(renderContentBlock)}
                    </div>
                    <div className="lesson-actions">
                        <Button variant="secondary" onClick={() => setModuleData(null)}>
                            Learn a New Topic
                        </Button>
                        <Button variant="primary" onClick={handleNextLesson} disabled={isLoading}>
                            {isLoading ? 'Generating...' : 'Next Lesson'}
                        </Button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Learn;