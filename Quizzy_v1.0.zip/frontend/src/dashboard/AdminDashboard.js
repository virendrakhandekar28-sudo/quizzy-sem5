// src/dashboard/AdminDashboard.js

import React, { useState, useEffect, useCallback } from 'react';
import * as adminService from '../services/adminService';
import Button from '../components/Button';
import Modal from '../components/modal';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('stats');
  const [data, setData] = useState({ stats: {}, users: [], leaderboard: [], logs: [], topics: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [selectedTopic, setSelectedTopic] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [isTopicModalOpen, setIsTopicModalOpen] = useState(false);
  const [isQuestionModalOpen, setIsQuestionModalOpen] = useState(false);

  const [newTopic, setNewTopic] = useState({ name: '', description: '' });
  const [newQuestion, setNewQuestion] = useState({ text: '', options: ['', '', '', ''], correctOption: 0, difficulty: 'Medium' });

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [statsData, usersData, leaderboardData, logsData, topicsData] = await Promise.all([
        adminService.getDashboardStats(), adminService.getAllUsers(),
        adminService.getFullLeaderboard(), adminService.getAiUsageLogs(), adminService.getAdminTopics()
      ]);
      setData({ stats: statsData, users: usersData, leaderboard: leaderboardData, logs: logsData, topics: topicsData });
    } catch (ex) {
      console.error("Admin Fetch Error:", ex);
      setError(ex.response?.data || 'Failed to load admin data. Please try refreshing the page.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  useEffect(() => {
    if (selectedTopic) {
      const fetchQuestions = async () => {
        try {
          const questionsData = await adminService.getQuestionsForTopic(selectedTopic.id);
          setQuestions(questionsData);
        } catch (ex) {
          setError('Failed to fetch questions for this topic.');
        }
      };
      fetchQuestions();
    } else {
      setQuestions([]);
    }
  }, [selectedTopic]);

  const handleBlockToggle = async (userId, isBlocked) => {
    if (!window.confirm(`Are you sure you want to ${isBlocked ? 'unblock' : 'block'} this user?`)) return;
    try {
      if (isBlocked) await adminService.unblockUser(userId);
      else await adminService.blockUser(userId);
      fetchData();
    } catch (ex) { alert('Failed to update user status.'); }
  };
  
  const handleScoreReset = async (userId, userName) => {
    if (!window.confirm(`Are you sure you want to reset the score for "${userName}" to zero? This action cannot be undone.`)) return;
    try {
      await adminService.resetUserScore(userId);
      fetchData();
    } catch (ex) { alert('Failed to reset user score.'); }
  };

  const handleAddTopic = async () => {
    if (!newTopic.name) { alert("Topic name cannot be empty."); return; }
    try {
      await adminService.addAdminTopic(newTopic);
      setIsTopicModalOpen(false);
      setNewTopic({ name: '', description: '' });
      fetchData();
    } catch (ex) { alert(ex.response?.data || "Failed to add topic."); }
  };

  const handleAddQuestion = async () => {
    if (!newQuestion.text || newQuestion.options.some(opt => !opt)) {
      alert("Question text and all four options are required."); return;
    }
    try {
      await adminService.addAdminQuestion({ ...newQuestion, topicId: selectedTopic.id });
      setIsQuestionModalOpen(false);
      setNewQuestion({ text: '', options: ['', '', '', ''], correctOption: 0, difficulty: 'Medium' });
      const questionsData = await adminService.getQuestionsForTopic(selectedTopic.id);
      setQuestions(questionsData);
      // Also refresh topics to update question count
      const topicsData = await adminService.getAdminTopics();
      setData(prev => ({...prev, topics: topicsData}));
    } catch (ex) { alert(ex.response?.data || "Failed to add question."); }
  };

  const renderContent = () => {
    if (loading) return <div className="loading-message">Loading Admin Data...</div>;
    if (error) return <div className="error-message">{error}</div>;

    switch (activeTab) {
      case 'stats':
        return (
          <div><h2>Overall Statistics</h2><div className="stats-grid">
            <div className="stat-card"><span className="label">Total Users</span><span className="value">{data.stats.totalUsers || 0}</span></div>
            <div className="stat-card"><span className="label">Database Quizzes Taken</span><span className="value">{data.stats.totalQuizzes || 0}</span></div>
            <div className="stat-card"><span className="label">Endless Players</span><span className="value">{data.stats.totalEndlessRuns || 0}</span></div>
            <div className="stat-card"><span className="label">Database Topics</span><span className="value">{data.stats.totalTopics || 0}</span></div>
          </div></div>
        );
      case 'users':
        return (
          <div><h2>User Management</h2><div className="admin-table-wrapper"><table className="admin-table">
            <thead><tr><th>Name</th><th>Email</th><th>Status</th><th className="actions-cell">Actions</th></tr></thead>
            <tbody>{data.users.map((user) => (<tr key={user._id}><td>{user.name}</td><td>{user.email}</td>
                <td><span className={`user-status ${user.isBlocked ? 'status-blocked' : 'status-active'}`}>{user.isBlocked ? 'Blocked' : 'Active'}</span></td>
                <td className="actions-cell"><Button variant={user.isBlocked ? 'success' : 'danger'} onClick={() => handleBlockToggle(user._id, user.isBlocked)}>{user.isBlocked ? 'Unblock' : 'Block'}</Button></td>
            </tr>))}</tbody>
          </table></div></div>
        );
      case 'leaderboard':
        return (
          <div><h2>Leaderboard Management</h2><div className="admin-table-wrapper"><table className="admin-table">
            <thead><tr><th>Rank</th><th>Player</th><th>Total Questions</th><th>Last Played</th><th className="actions-cell">Total Score</th><th>Actions</th></tr></thead>
            <tbody>{data.leaderboard.map((entry, index) => (<tr key={entry.userId}>
                <td>{index + 1}</td><td>{entry.userName}</td><td>{entry.total_questions_answered}</td><td>{new Date(entry.last_played_at).toLocaleString()}</td>
                <td className="actions-cell"><span className="leaderboard-score">{entry.total_score}</span></td>
                <td className="actions-cell"><Button variant="danger" onClick={() => handleScoreReset(entry.userId, entry.userName)}>Reset Score</Button></td>
            </tr>))}</tbody>
          </table></div></div>
        );
      case 'logs':
        return (
          <div><h2>AI Usage Logs</h2><div className="admin-table-wrapper"><table className="admin-table">
            <thead><tr><th>Date</th><th>User</th><th>Feature</th><th>Topic Prompt</th></tr></thead>
            <tbody>{data.logs.map((log) => (<tr key={log.id}>
                <td>{new Date(log.createdAt).toLocaleString()}</td><td>{log.userName}</td>
                <td><span className="log-feature-tag">{log.feature_used}</span></td><td>{log.topic_prompt}</td>
            </tr>))}</tbody>
          </table></div></div>
        );
      case 'topics':
        return (
          <div><h2>Topic & Question Management</h2><div className="topic-management-layout">
              <div className="topics-panel">
                <div className="panel-header"><h3>Topics ({data.topics.length})</h3><Button onClick={() => setIsTopicModalOpen(true)}>Add Topic</Button></div>
                <ul className="topics-list">{data.topics.map(topic => (<li key={topic.id} className={`topic-list-item ${selectedTopic?.id === topic.id ? 'selected' : ''}`} onClick={() => setSelectedTopic(topic)}>
                    {topic.name} <span>({topic.questionCount})</span></li>))}</ul>
              </div>
              <div className="questions-panel">
                {selectedTopic ? (<>
                    <div className="panel-header"><h3>Questions for "{selectedTopic.name}"</h3><Button onClick={() => setIsQuestionModalOpen(true)}>Add Question</Button></div>
                    {questions.length > 0 ? (questions.map(q => (<div key={q.id} className="question-list-item"><p>{q.text} <span className="difficulty">{q.difficulty}</span></p></div>))) 
                    : (<div className="no-questions-message">No questions found for this topic yet.</div>)}
                </>) : (<div className="no-topic-selected">Select a topic from the left to view its questions.</div>)}
              </div>
          </div></div>
        );
      default: return null;
    }
  };

  return (
    <div className="admin-dashboard">
      <h1>Admin Dashboard</h1>
      <div className="admin-tabs">
        <button className={`admin-tab ${activeTab === 'stats' ? 'active' : ''}`} onClick={() => setActiveTab('stats')}>Statistics</button>
        <button className={`admin-tab ${activeTab === 'users' ? 'active' : ''}`} onClick={() => setActiveTab('users')}>Users</button>
        <button className={`admin-tab ${activeTab === 'leaderboard' ? 'active' : ''}`} onClick={() => setActiveTab('leaderboard')}>Leaderboard</button>
        <button className={`admin-tab ${activeTab === 'logs' ? 'active' : ''}`} onClick={() => setActiveTab('logs')}>AI Logs</button>
        <button className={`admin-tab ${activeTab === 'topics' ? 'active' : ''}`} onClick={() => setActiveTab('topics')}>Content</button>
      </div>
      <div className="admin-tab-content">{renderContent()}</div>

      <Modal isOpen={isTopicModalOpen} onClose={() => setIsTopicModalOpen(false)} title="Add New Topic">
        <div className="form-group"><label htmlFor="topicName">Topic Name</label><input type="text" id="topicName" value={newTopic.name} onChange={e => setNewTopic({ ...newTopic, name: e.target.value })} /></div>
        <div className="form-group"><label htmlFor="topicDesc">Description (Optional)</label><textarea id="topicDesc" rows="3" value={newTopic.description} onChange={e => setNewTopic({ ...newTopic, description: e.target.value })} /></div>
        <div className="modal-footer"><Button variant="secondary" onClick={() => setIsTopicModalOpen(false)}>Cancel</Button><Button variant="primary" onClick={handleAddTopic}>Save Topic</Button></div>
      </Modal>
      <Modal isOpen={isQuestionModalOpen} onClose={() => setIsQuestionModalOpen(false)} title={`Add Question to "${selectedTopic?.name}"`}>
        <div className="form-group"><label htmlFor="qText">Question Text</label><textarea id="qText" rows="3" value={newQuestion.text} onChange={e => setNewQuestion({ ...newQuestion, text: e.target.value })} /></div>
        <div className="form-group options-group"><label>Options (Provide 4 options)</label><div className="options-inputs">
            {newQuestion.options.map((opt, index) => (<input key={index} type="text" value={opt} onChange={e => {
                const newOpts = [...newQuestion.options]; newOpts[index] = e.target.value; setNewQuestion({ ...newQuestion, options: newOpts });
            }} placeholder={`Option ${index + 1}`} />))}
        </div></div>
        <div className="form-grid">
            <div className="form-group"><label htmlFor="correctOpt">Correct Option</label><select id="correctOpt" value={newQuestion.correctOption} onChange={e => setNewQuestion({ ...newQuestion, correctOption: Number(e.target.value) })}>
                <option value={0}>Option 1</option><option value={1}>Option 2</option><option value={2}>Option 3</option><option value={3}>Option 4</option></select></div>
            <div className="form-group"><label htmlFor="difficulty">Difficulty</label><select id="difficulty" value={newQuestion.difficulty} onChange={e => setNewQuestion({ ...newQuestion, difficulty: e.target.value })}>
                <option value="Easy">Easy</option><option value="Medium">Medium</option><option value="Hard">Hard</option></select></div>
        </div>
        <div className="modal-footer"><Button variant="secondary" onClick={() => setIsQuestionModalOpen(false)}>Cancel</Button><Button variant="primary" onClick={handleAddQuestion}>Save Question</Button></div>
      </Modal>
    </div>
  );
};

export default AdminDashboard;