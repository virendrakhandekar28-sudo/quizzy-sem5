// src/dashboard/UserDashboard.js

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import * as quizService from '../services/quizService';
import * as authService from '../services/authService';
import Button from '../components/Button';
import './UserDashboard.css';

// --- Import Chart.js components ---
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

// --- Register the components we need for a line chart ---
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const UserDashboard = () => {
  const [history, setHistory] = useState([]);
  const [chartData, setChartData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const user = authService.getCurrentUser();

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        setLoading(true);
        setError('');
        const data = await quizService.getUserHistory();
        const sortedData = data.slice().reverse();
        setHistory(data);

        if (sortedData.length > 1) {
          const labels = sortedData.map(item => 
            new Date(item.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
          );
          const scores = sortedData.map(item => 
            (item.score / item.totalQuestions) * 100
          );

          setChartData({
            labels,
            datasets: [
              {
                label: 'Quiz Score %',
                data: scores,
                borderColor: 'rgb(74, 20, 140)',
                backgroundColor: 'rgba(74, 20, 140, 0.5)',
                tension: 0.1,
              },
            ],
          });
        }
      } catch (ex) {
        setError('Failed to load your quiz history.');
        console.error(ex);
      } finally {
        setLoading(false);
      }
    };

    fetchHistory();
  }, []);

  const getScoreBadgeClass = (score, total) => {
    const percentage = total > 0 ? (score / total) * 100 : 0;
    if (percentage >= 75) return 'score-high';
    if (percentage >= 40) return 'score-medium';
    return 'score-low';
  };
  
  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Your Progress Over Time',
        font: { size: 16 }
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        ticks: {
          callback: function(value) {
            return value + '%';
          }
        }
      }
    }
  };

  if (loading) return <div className="loading-message">Loading Dashboard...</div>;
  if (error) return <div className="error-message">{error}</div>;

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <h1>Welcome, {user?.name}!</h1>
        {/* --- THIS IS THE MODIFIED LINE --- */}
        <Link to="/quiz-gen">
          <Button variant="primary">Start a New Quiz</Button>
        </Link>
      </div>

      <div className="dashboard-card progress-chart-container">
        <h2>Your Progress</h2>
        {chartData ? (
          <Line options={chartOptions} data={chartData} />
        ) : (
          <div className="chart-placeholder-message">
            <p>You need to complete at least two quizzes to see your progress chart.</p>
          </div>
        )}
      </div>
      
      <div className="dashboard-card">
        <h2>Your Quiz History</h2>
        {history.length === 0 ? (
          <div className="empty-history-message">
            <p>You haven't taken any quizzes from our database yet.</p>
            {/* Kept this secondary button for users who still want to browse the pre-made quizzes */}
            <Link to="/topics">
              <Button variant="secondary">Browse Pre-made Quizzes</Button>
            </Link>
          </div>
        ) : (
          <table className="history-table">
            <thead>
              <tr>
                <th>Topic</th>
                <th>Score</th>
                <th>Accuracy</th>
                <th>Date Taken</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {history.map((item) => (
                <tr key={item._id}>
                  <td>{item.topic.name}</td>
                  <td>
                    <span className={`score-badge ${getScoreBadgeClass(item.score, item.totalQuestions)}`}>
                      {item.score}/{item.totalQuestions}
                    </span>
                  </td>
                  <td>{((item.score / item.totalQuestions) * 100).toFixed(2)}%</td>
                  <td>{new Date(item.createdAt).toLocaleDateString()}</td>
                  <td>
                    <Link to={`/results/${item._id}`}>
                      <Button variant="secondary">View Details</Button>
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default UserDashboard;