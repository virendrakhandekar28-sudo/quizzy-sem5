// src/quiz-gen/QuizGenerator.js

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import * as aiQuizService from '../services/aiQuizService';
import { logAiEvent } from '../services/loggingService';
import Button from '../components/Button';
import './QuizGenerator.css';

const QuizGenerator = () => {
  const [topic, setTopic] = useState('');
  const [difficulty, setDifficulty] = useState('Medium');
  const [numQuestions, setNumQuestions] = useState(5);
  const [duration, setDuration] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [generatedQuiz, setGeneratedQuiz] = useState(null);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!topic) { setError('Please enter a topic for your quiz.'); return; }
    setIsLoading(true);
    setError('');
    setGeneratedQuiz(null);
    try {
      const questions = await aiQuizService.generateQuizBatch({
        topic,
        difficulty,
        numQuestions,
        model: 'qwen3:4b',
      });

      const quizData = {
        topic: topic,
        difficulty: difficulty,
        questions: questions,
      };
      
      logAiEvent('Quiz Generator', topic);
      setGeneratedQuiz(quizData);

    } catch (err) {
      setError(err.message || 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartQuiz = () => {
    if (!generatedQuiz) return;
    const quizPayload = { quizData: generatedQuiz, duration };
    // Save to localStorage as a fallback for page refreshes
    localStorage.setItem('generatedQuiz', JSON.stringify(quizPayload));
    // Pass data directly via navigation state to avoid race conditions
    navigate('/quiz/generated', { state: { quizPayload } });
  };

  const handleExport = () => {
    if (!generatedQuiz) return;
    const jsonString = JSON.stringify(generatedQuiz, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const safeTopic = (generatedQuiz.topic || 'quiz').replace(/[^a-z0-9]/gi, '_').toLowerCase();
    link.download = `quiz_${safeTopic}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleFileImport = (event) => {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedQuiz = JSON.parse(e.target.result);
        if (importedQuiz && importedQuiz.questions && Array.isArray(importedQuiz.questions)) {
          const payload = { quizData: importedQuiz, duration: importedQuiz.questions.length };
          localStorage.setItem('generatedQuiz', JSON.stringify(payload));
          // For imports, we navigate and let the component load from localStorage
          navigate('/quiz/generated');
        } else {
          setError('Invalid quiz file format.');
        }
      } catch (error) {
        setError('Failed to parse file. Please ensure it is a valid JSON quiz file.');
      }
    };
    reader.readAsText(file);
  };

  if (isLoading) {
    return (
        <div className="generator-container">
            <div className="loading-container">
                <div className="spinner"></div>
                <p className="loading-text">Generating your quiz... This may take a moment.</p>
            </div>
        </div>
    );
  }

  if (generatedQuiz) {
    return (
        <div className="generator-container">
            <div className="generation-success">
                <h3>Quiz Generated Successfully!</h3>
                <p>Your quiz on "{generatedQuiz.topic}" is ready.</p>
                <div className="success-actions">
                    <Button variant="success" onClick={handleStartQuiz}>Start Quiz</Button>
                    <Button variant="secondary" onClick={handleExport}>Export as JSON</Button>
                    <Button variant="primary" onClick={() => setGeneratedQuiz(null)}>Generate Another</Button>
                </div>
            </div>
        </div>
    );
  }

  return (
    <div className="generator-container">
        <h1>AI Quiz Generator</h1>
        <form onSubmit={handleSubmit} className="generator-form">
            <div className="form-grid">
                <div className="form-group topic-group">
                    <label htmlFor="topic">Quiz Topic</label>
                    <input type="text" id="topic" value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="e.g., Roman History, React Hooks"/>
                </div>
                <div className="form-group">
                    <label htmlFor="difficulty">Difficulty</label>
                    <select id="difficulty" value={difficulty} onChange={(e) => setDifficulty(e.target.value)}>
                        <option value="Easy">Easy</option>
                        <option value="Medium">Medium</option>
                        <option value="Hard">Hard</option>
                    </select>
                </div>
                <div className="form-group">
                    <label htmlFor="numQuestions">Number of Questions</label>
                    <input type="number" id="numQuestions" value={numQuestions} onChange={(e) => setNumQuestions(Number(e.target.value))} min="1" max="20"/>
                </div>
                <div className="form-group">
                    <label htmlFor="duration">Timer (minutes)</label>
                    <input type="number" id="duration" value={duration} onChange={(e) => setDuration(Number(e.target.value))} min="1" max="120"/>
                </div>
            </div>
            {error && <p className="generator-error">{error}</p>}
            <div className="generator-actions">
                <Button type="submit" variant="primary">Generate Quiz</Button>
                <label htmlFor="import-quiz-gen" className="import-label">Import Quiz</label>
                <input id="import-quiz-gen" type="file" accept=".json,application/json" onChange={handleFileImport} className="import-input"/>
            </div>
        </form>
    </div>
  );
};

export default QuizGenerator;