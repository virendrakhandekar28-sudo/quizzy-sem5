// src/quiz-gen/GeneratedQuiz.js

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Button from '../components/Button';
import './GeneratedQuiz.css';
import * as quizService from '../services/quizService';

const GeneratedQuiz = () => {
    const [quizData, setQuizData] = useState(null);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [answers, setAnswers] = useState({});
    const [bookmarks, setBookmarks] = useState({});
    const [timeLeft, setTimeLeft] = useState(600);
    const [quizState, setQuizState] = useState('loading');
    const [importError, setImportError] = useState('');
    const navigate = useNavigate();
    const location = useLocation();

    // Normalize potentially varying AI/JSON shapes to the UI's expected schema
    const normalizeQuizData = (rawData) => {
        if (!rawData || !Array.isArray(rawData.questions)) return null;
        const normalizedQuestions = rawData.questions.map((q, idx) => {
            const text = q.text || q.question || q.prompt || q.title || `Question ${idx + 1}`;
            let options = q.options || q.choices || q.answers || [];
            // Normalize options to string array
            if (Array.isArray(options)) {
                options = options.map(opt => {
                    if (opt == null) return '';
                    if (typeof opt === 'object') {
                        return String(opt.text || opt.label || opt.value || '').trim();
                    }
                    return String(opt).trim();
                });
            } else {
                options = [];
            }
            // Enforce exactly 4 options
            if (options.length > 4) options = options.slice(0, 4);
            if (options.length < 4) {
                const pads = new Array(4 - options.length).fill('');
                options = [...options, ...pads];
            }
            // Determine correct option index from various possible keys (numeric only)
            let correctOption = q.correctOption;
            if (typeof correctOption === 'string' && /^\d+$/.test(correctOption)) {
                correctOption = parseInt(correctOption, 10);
            }
            if (typeof correctOption !== 'number') {
                correctOption = q.correctIndex ?? q.answerIndex;
            }
            // Final guard: ensure in range 0..3
            if (typeof correctOption === 'number') {
                if (!(correctOption >= 0 && correctOption < 4)) {
                    correctOption = undefined;
                }
            }
            const explanation = q.explanation || q.explain || q.reason || '';
            const difficulty = q.difficulty || q.level || 'Medium';
            return {
                ...q,
                text,
                options,
                correctOption,
                explanation,
                difficulty,
            };
        });
        return { ...rawData, questions: normalizedQuestions };
    };

    // --- CRITICAL FIX: Use a ref to ensure the loading logic runs only ONCE ---
    const hasLoaded = useRef(false);

    useEffect(() => {
        // This condition prevents the effect from re-running due to Strict Mode
        if (hasLoaded.current) return;
        hasLoaded.current = true;

        const payloadFromState = location.state?.quizPayload;

        if (payloadFromState) {
            console.log("Loading quiz from navigation state.");
            const normalized = normalizeQuizData(payloadFromState.quizData);
            initializeQuiz(normalized, payloadFromState.duration);
            localStorage.setItem('generatedQuiz', JSON.stringify(payloadFromState));
            window.history.replaceState({}, document.title);
        } else {
            console.log("No state found, falling back to localStorage.");
            try {
                const storedPayload = localStorage.getItem('generatedQuiz');
                if (storedPayload) {
                    const payload = JSON.parse(storedPayload);
                    const normalized = normalizeQuizData(payload.quizData);
                    initializeQuiz(normalized, payload.duration);
                } else {
                    setQuizState('import');
                }
            } catch (error) {
                setImportError('Failed to load quiz from storage. It may be corrupted.');
                setQuizState('import');
            }
        }
    }, []); // The empty dependency array is correct.

    const initializeQuiz = (data, durationInMinutes) => {
        if (data && data.questions && Array.isArray(data.questions)) {
            setQuizData(data);
            setTimeLeft(durationInMinutes * 60);
            setQuizState('active');
            setCurrentQuestionIndex(0);
            setAnswers({});
            setBookmarks({});
            setImportError('');
        } else {
            setImportError('Invalid or corrupted quiz file format.');
            setQuizState('import');
        }
    };

    const handleQuizEnd = useCallback(async () => {
        if (!quizData || !Array.isArray(quizData.questions)) { setQuizState('finished'); return; }
        const score = quizData.questions.reduce((acc, q, idx) => (
            acc + (answers[idx] === q.correctOption ? 1 : 0)
        ), 0);
        try {
            await quizService.saveGeneratedQuizResult({
                topicName: quizData.topic || quizData.title || 'AI Generated Quiz',
                score,
                totalQuestions: quizData.questions.length,
            });
        } catch (e) {
            // Non-blocking: still show results locally
            console.error('Failed to save AI quiz result:', e);
        } finally {
            setQuizState('finished');
        }
    }, [quizData, answers]);

    useEffect(() => {
        if (quizState !== 'active') return;
        if (timeLeft <= 0) { handleQuizEnd(); return; }
        const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
        return () => clearInterval(timer);
    }, [quizState, timeLeft, handleQuizEnd]);
    const handleOptionSelect = (optionIndex) => setAnswers({ ...answers, [currentQuestionIndex]: optionIndex });
    const jumpToQuestion = (index) => setCurrentQuestionIndex(index);
    const toggleBookmark = () => setBookmarks(prev => ({ ...prev, [currentQuestionIndex]: !prev[currentQuestionIndex] }));
    
    const handleFileImport = (event) => {
        const file = event.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedQuiz = JSON.parse(e.target.result);
                if (importedQuiz && importedQuiz.questions && Array.isArray(importedQuiz.questions)) {
                    const normalized = normalizeQuizData(importedQuiz);
                    initializeQuiz(normalized, normalized.questions.length);
                    const payload = { quizData: normalized, duration: normalized.questions.length };
                    localStorage.setItem('generatedQuiz', JSON.stringify(payload));
                } else {
                    setImportError('Invalid quiz file format.');
                }
            } catch (error) {
                setImportError('Failed to parse file. Please ensure it is a valid JSON quiz file.');
            }
        };
        reader.readAsText(file);
    };

    const handleExport = () => {
        if (!quizData) return;
        const jsonString = JSON.stringify(quizData, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        const safeTopic = (quizData.topic || 'quiz').replace(/[^a-z0-9]/gi, '_').toLowerCase();
        link.download = `quiz_${safeTopic}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };


    // --- RENDER LOGIC (Unchanged) ---
    if (quizState === 'loading') {
        return <div className="loading-message">Loading Quiz...</div>;
    }
    if (quizState === 'import') {
        return (
            <div className="quiz-card import-container">
                <h2>Take a Generated Quiz</h2>
                <p>Load a quiz from your last AI generation or import a quiz JSON file to begin.</p>
                <label htmlFor="import-quiz" className="import-label">Import Quiz File</label>
                <input id="import-quiz" type="file" accept=".json,application/json" onChange={handleFileImport} className="import-input" />
                {importError && <p className="import-error" style={{marginTop: '1rem'}}>{importError}</p>}
            </div>
        );
    }
    if (quizState === 'finished') {
        const score = Object.keys(answers).reduce((acc, index) => {
            const question = quizData.questions[index];
            return question.correctOption === answers[index] ? acc + 1 : acc;
        }, 0);
        const total = quizData.questions.length;
        const accuracy = total > 0 ? ((score / total) * 100).toFixed(1) : 0;
        return (
            <div className="quiz-card results-view">
                <h1>Quiz Complete!</h1>
                <div className="results-summary">
                    <div className="summary-item"><span className="label">Your Score</span><span className="value">{score}/{total}</span></div>
                    <div className="summary-item"><span className="label">Accuracy</span><span className="value">{accuracy}%</span></div>
                </div>
                <div className="quiz-navigation">
                    <Button variant="primary" onClick={() => { setQuizState('reviewing'); setCurrentQuestionIndex(0); }}>Review Answers</Button>
                    <Button variant="secondary" onClick={handleExport}>Export Quiz</Button>
                    <Button onClick={() => navigate('/dashboard')}>Go to Dashboard</Button>
                </div>
            </div>
        );
    }
    
    const currentQuestion = quizData?.questions[currentQuestionIndex];
    if (!currentQuestion) {
        return <div className="loading-message">Loading Question...</div>;
    }
    const isReviewing = quizState === 'reviewing';

    return (
        <div className="quiz-page-layout">
            <div className="quiz-main-content">
                <div className="quiz-card">
                    <div className="quiz-header">
                        <h3>Question {currentQuestionIndex + 1}</h3>
                        {!isReviewing && (
                            <Button variant={bookmarks[currentQuestionIndex] ? 'secondary' : 'primary'} onClick={toggleBookmark}>
                                {bookmarks[currentQuestionIndex] ? '★ Unbookmark' : '★ Bookmark'}
                            </Button>
                        )}
                    </div>
                    <p className="question-text">{currentQuestion.text}</p>
                    <ul className="options-list">
                        {currentQuestion.options.map((option, index) => {
                            let optionClass = 'option-item';
                            if (isReviewing) {
                                if (index === currentQuestion.correctOption) optionClass += ' correct-answer';
                                else if (index === answers[currentQuestionIndex]) optionClass += ' wrong-answer';
                            } else {
                                if (answers[currentQuestionIndex] === index) optionClass += ' selected';
                            }
                            return (<li key={index}><button className={optionClass} onClick={() => !isReviewing && handleOptionSelect(index)} disabled={isReviewing}>{option}</button></li>);
                        })}
                    </ul>
                    <div className="quiz-navigation">
                        <Button onClick={() => setCurrentQuestionIndex(p => p - 1)} disabled={currentQuestionIndex === 0}>Prev</Button>
                        {isReviewing ? (
                            currentQuestionIndex === quizData.questions.length - 1 ?
                            (<Button onClick={() => setQuizState('finished')} variant="success">Finish Review</Button>) :
                            (<Button onClick={() => setCurrentQuestionIndex(p => p + 1)}>Next</Button>)
                        ) : (
                            currentQuestionIndex === quizData.questions.length - 1 ?
                            (<Button onClick={handleQuizEnd} variant="success">Submit Quiz</Button>) :
                            (<Button onClick={() => setCurrentQuestionIndex(p => p + 1)}>Next</Button>)
                        )}
                    </div>
                </div>
                {isReviewing && currentQuestion.explanation && (
                    <div className="explanation-card">
                        <h4>Explanation</h4>
                        <p>{currentQuestion.explanation}</p>
                    </div>
                )}
            </div>
            <div className="quiz-sidebar">
                <div className="question-palette-card">
                    <div className="palette-header">
                        <h3>Question Palette</h3>
                        <div className="quiz-timer">{Math.floor(timeLeft / 60)}:{('0' + (timeLeft % 60)).slice(-2)}</div>
                    </div>
                    <div className="palette-grid">
                        {quizData.questions.map((q, index) => {
                            let paletteClass = 'palette-button';
                            if (isReviewing) {
                                if (answers[index] === q.correctOption) paletteClass += ' review-correct';
                                else paletteClass += ' review-incorrect';
                            } else {
                                if (answers[index] !== undefined) paletteClass += ' attempted';
                                if (bookmarks[index]) paletteClass += ' bookmarked';
                            }
                            if (index === currentQuestionIndex) paletteClass += ' current';
                            return (<button key={index} className={paletteClass} onClick={() => jumpToQuestion(index)}>{index + 1}</button>);
                        })}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default GeneratedQuiz;