// src/components/Modal.js

import React, { useEffect } from 'react';
import './Modal.css';

/**
 * A reusable Modal component.
 * 
 * @param {object} props
 * @param {boolean} props.isOpen - Controls whether the modal is visible.
 * @param {function} props.onClose - Function to call when the modal should be closed.
 * @param {string} props.title - The title to display in the modal header.
 * @param {React.ReactNode} props.children - The content to display in the modal body.
 * @param {React.ReactNode} [props.footer] - Optional content to display in the modal footer (e.g., action buttons).
 */
const Modal = ({ isOpen, onClose, title, children, footer }) => {

  // Effect to handle the 'Escape' key press to close the modal
  useEffect(() => {
    const handleEsc = (event) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleEsc);
    }
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  // Prevent clicks inside the modal content from closing it
  const handleContentClick = (e) => {
    e.stopPropagation();
  };

  if (!isOpen) {
    return null; // Don't render anything if the modal is not open
  }

  return (
    // The overlay is the semi-transparent background
    <div className="modal-overlay" onClick={onClose}>
      {/* The main modal content box */}
      <div className="modal-content" onClick={handleContentClick}>
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="modal-close-button" onClick={onClose}>
            &times; {/* This is the 'X' symbol */}
          </button>
        </div>
        <div className="modal-body">
          {children}
        </div>
        {footer && (
          <div className="modal-footer">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};

export default Modal;