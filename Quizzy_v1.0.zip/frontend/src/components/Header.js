// src/components/Header.js

import React, { useState, useEffect } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import * as authService from '../services/authService';
import logo from '../assets/logo.png';
import './Header.css';

const Header = () => {
  const [currentUser, setCurrentUser] = useState(null);
  const [isQuizDropdownOpen, setIsQuizDropdownOpen] = useState(false);
  const [isTopicsDropdownOpen, setIsTopicsDropdownOpen] = useState(false);
  const [isUsersDropdownOpen, setIsUsersDropdownOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const user = authService.getCurrentUser();
    if (user) {
      setCurrentUser(user);
    }
  }, []);

  const handleLogout = () => {
    authService.logout();
    setCurrentUser(null);
    navigate('/login');
  };

  return (
    <header className="app-header">
      <div className="header-container">
        <div className="header-logo">
          <Link to="/">
            <img src={logo} alt="Quizzy Logo" />
            <span>Quizzy</span>
          </Link>
        </div>
        <nav className="header-nav">
          <ul>
            {!currentUser ? (
              // Links for logged-out users
              <>
                <li><NavLink to="/login" className={({ isActive }) => isActive ? 'active-link' : ''}>Login</NavLink></li>
                <li><NavLink to="/register" className={({ isActive }) => isActive ? 'active-link' : ''}>Register</NavLink></li>
              </>
            ) : (
              // Links for logged-in users
              <>
                {currentUser.role === 'admin' ? (
                  // Links for ADMIN user
                  <li><NavLink to="/admin" className={({ isActive }) => isActive ? 'active-link' : ''}>Admin Dashboard</NavLink></li>
                ) : (
                  // Links for REGULAR user
                  <>
                    <li><NavLink to="/dashboard" className={({ isActive }) => isActive ? 'active-link' : ''}>Dashboard</NavLink></li>
                    <li><NavLink to="/chat" className={({ isActive }) => isActive ? 'active-link' : ''}>Chat Quizzy</NavLink></li>
                    {/* --- "Topics" Dropdown --- */}
                    <li 
                      className="dropdown-menu-item"
                      onMouseEnter={() => setIsTopicsDropdownOpen(true)}
                      onMouseLeave={() => setIsTopicsDropdownOpen(false)}
                    >
                      <button className="nav-button">Topics</button>
                      <ul className={`dropdown-menu ${isTopicsDropdownOpen ? 'open' : ''}`}>
                        <li><NavLink to="/learn">Learn (Interactive)</NavLink></li>
                        <li><NavLink to="/topics">Discover</NavLink></li>
                      </ul>
                    </li>
                    
                    {/* --- "AI Quiz" Dropdown --- */}
                    <li 
                      className="dropdown-menu-item"
                      onMouseEnter={() => setIsQuizDropdownOpen(true)}
                      onMouseLeave={() => setIsQuizDropdownOpen(false)}
                    >
                      <button className="nav-button">Quiz</button>
                      <ul className={`dropdown-menu ${isQuizDropdownOpen ? 'open' : ''}`}>
                        <li><NavLink to="/quiz-gen">Ai Quiz</NavLink></li>
                        <li><NavLink to="/endless-quiz">Endless Mode</NavLink></li>
                      </ul>
                    </li>

                    {/* --- NEW: Direct Link to Chat --- */}
                  </>
                )}
                <li className="dropdown-menu-item"
                    onMouseEnter={() => setIsUsersDropdownOpen(true)}
                    onMouseLeave={() => setIsUsersDropdownOpen(false)}
                    >
                    <button className="nav-button"><span className="welcome-message">Welcome, {currentUser.name}!</span></button>
                    <ul className={`dropdown-menu ${isUsersDropdownOpen ? 'open' : ''}`}><li><button onClick={handleLogout} className="logout-button">Logout</button></li></ul>
                </li>
              </>
            )}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;