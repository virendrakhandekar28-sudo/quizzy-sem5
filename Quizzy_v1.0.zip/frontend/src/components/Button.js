// src/components/Button.js

import React from 'react';
import './Button.css';

/**
 * Reusable Button Component
 * 
 * @param {object} props - The properties for the component.
 * @param {React.ReactNode} props.children - The content inside the button (e.g., text or an icon).
 * @param {function} props.onClick - The function to execute when the button is clicked.
 * @param {string} [props.type='button'] - The HTML button type ('button', 'submit', 'reset').
 * @param {string} [props.variant='primary'] - The button style ('primary', 'secondary', 'success', 'danger').
 * @param {boolean} [props.disabled=false] - Whether the button is disabled.
 * @param {string} [props.className] - Additional CSS classes to apply.
 */
const Button = ({
  children,
  onClick,
  type = 'button',
  variant = 'primary',
  disabled = false,
  className = ''
}) => {
  // Determine the CSS class based on the variant prop
  const buttonClass = `btn btn-${variant}`;

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${buttonClass} ${className}`}
    >
      {children}
    </button>
  );
};

export default Button;