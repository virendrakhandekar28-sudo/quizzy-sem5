// src/components/Footer.js

import React from 'react';
import './Footer.css';

const Footer = () => {
    return (
        <footer className="footer">
            <div className="footer-content">
                <p>&copy; 2025 Quizzy. All rights reserved.</p>
                <p className="footer-tagline">Your AI-powered learning companion</p>
            </div>
        </footer>
    );
};

export default Footer;
