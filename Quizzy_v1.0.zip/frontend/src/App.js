// src/App.js

import React from 'react';
import { Routes, Route } from 'react-router-dom';

// Layout & Reusable Components
import Header from './components/Header';
import Footer from './components/Footer';

// Authentication Pages
import Login from './auth/Login';
import Register from './auth/Register';

// Dashboard Pages
import UserDashboard from './dashboard/UserDashboard';
import AdminDashboard from './dashboard/AdminDashboard';

// Quiz & Learn Pages
import TopicSelection from './quiz/TopicSelection';
import QuizEngine from './quiz/QuizEngine';
import Results from './quiz/Results';
import Learn from './learn/learn';

// AI-Powered Feature Pages
import QuizGenerator from './quiz-gen/QuizGenerator';
import GeneratedQuiz from './quiz-gen/GeneratedQuiz';
import EndlessQuiz from './endless/EndlessQuiz';
import Chat from './chat/chat'; // <-- NEW IMPORT


function App() {
  return (
    <div className="App">
      <Header />
      <main className="container">
        <Routes>
          {/* --- Authentication Routes --- */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          
          {/* --- Dashboard Routes --- */}
          <Route path="/" element={<UserDashboard />} /> 
          <Route path="/dashboard" element={<UserDashboard />} />
          <Route path="/admin" element={<AdminDashboard />} />

          {/* --- Core Learning & Quiz Routes --- */}
          <Route path="/topics" element={<TopicSelection />} />
          <Route path="/quiz/:topicId" element={<QuizEngine />} />
          <Route path="/results/:sessionId" element={<Results />} />
          <Route path="/learn" element={<Learn />} />

          {/* --- AI-Powered Feature Routes --- */}
          <Route path="/quiz-gen" element={<QuizGenerator />} />
          <Route path="/quiz/generated" element={<GeneratedQuiz />} />
          <Route path="/endless-quiz" element={<EndlessQuiz />} />
          <Route path="/chat" element={<Chat />} /> {/* <-- NEW ROUTE */}
          
          {/* --- Fallback Route --- */}
          <Route path="*" element={
            <div style={{ textAlign: 'center', marginTop: '50px' }}>
              <h2>404 - Page Not Found</h2>
              <p>The page you are looking for does not exist.</p>
            </div>
          } />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;