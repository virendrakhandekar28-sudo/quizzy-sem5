import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import * as quizService from '../services/quizService';
import Button from '../components/Button';
import './Results.css';

const Results = () => {
  const { sessionId } = useParams();
  const navigate = useNavigate();
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchResults = async () => {
      try {
        setLoading(true);
        setError('');
        const data = await quizService.getResults(sessionId);
        setResults(data);
      } catch (ex) {
        setError('Failed to load quiz results. Please try again.');
        console.error(ex);
      } finally {
        setLoading(false);
      }
    };

    fetchResults();
  }, [sessionId]);

  if (loading) return <div className="loading-message">Calculating Your Results...</div>;
  if (error) return <div className="error-message">{error}</div>;
  if (!results) return <div>No results found for this session.</div>;

  const { score, totalQuestions, details } = results;
  const accuracy = totalQuestions > 0 ? ((score / totalQuestions) * 100).toFixed(2) : 0;

  return (
    <div className="results-container">
      <h1>Quiz Complete!</h1>

      <div className="results-summary">
        <div className="summary-item">
          <span className="label">Your Score</span>
          <span className="value">{score}/{totalQuestions}</span>
        </div>
        <div className="summary-item">
          <span className="label">Accuracy</span>
          <span className="value">{accuracy}%</span>
        </div>
      </div>

      <div className="question-review-section">
        <h2>Question Review</h2>
        {details.map((item, index) => (
          <div key={item.question._id} className="reviewed-question">
            <h4>{index + 1}. {item.question.text}</h4>
            <div className="options">
              <ul>
                {item.question.options.map((option, optIndex) => {
                  let className = '';
                  if (optIndex === item.question.correctOption) {
                    className = 'correct-answer'; // Always highlight the correct answer
                  } else if (optIndex === item.userAnswer && item.userAnswer !== item.question.correctOption) {
                    className = 'wrong-answer'; // Highlight the user's wrong answer
                  }
                  return <li key={optIndex} className={className}>{option}</li>;
                })}
              </ul>
            </div>
          </div>
        ))}
      </div>

      <div className="results-actions">
        <Button onClick={() => navigate(`/quiz/${results.topicId}`)} variant="primary">
          Try Again
        </Button>
        <Link to="/dashboard">
          <Button variant="secondary">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
};

export default Results;