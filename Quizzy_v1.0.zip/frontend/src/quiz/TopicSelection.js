// src/quiz/TopicSelection.js

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import * as quizService from '../services/quizService';
import Button from '../components/Button';
import './TopicSelection.css';

const TopicSelection = () => {
  const [topics, setTopics] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchTopics = async () => {
      try {
        setLoading(true);
        setError('');
        const data = await quizService.getTopics();
        setTopics(data);
      } catch (ex) {
        setError('Failed to load topics. Please try refreshing the page.');
        console.error(ex);
      } finally {
        setLoading(false);
      }
    };

    fetchTopics();
  }, []);

  const handleTopicSelect = (topicId) => {
    navigate(`/quiz/${topicId}`);
  };

  if (loading) {
    return <div className="loading-message">Loading Topics...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div className="topic-selection-container">
      <h1>Choose a Topic</h1>
      <div className="topic-grid">
        {topics.map((topic) => (
          <div
            key={topic._id}
            className="topic-card"
            onClick={() => handleTopicSelect(topic._id)}
          >
            <h3>{topic.name}</h3>
            <p>{topic.description || 'A challenging quiz to test your knowledge.'}</p>
            <div className="topic-card-footer">
              {/* Display the count, but don't use it to disable the card */}
              <span>{topic.questionCount || '0'} Questions</span>
              <Button variant="secondary">Start Quiz</Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TopicSelection;