// src/quiz/QuizEngine.js

import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import * as quizService from '../services/quizService';
import Button from '../components/Button';
import './QuizEngine.css';

const QuizEngine = () => {
  const { topicId } = useParams();
  const navigate = useNavigate();

  const [session, setSession] = useState(null);
  const [topicName, setTopicName] = useState('');
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [bookmarks, setBookmarks] = useState({});
  const [timeLeft, setTimeLeft] = useState(300);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const startNewQuiz = async () => {
      try {
        setLoading(true);
        setError('');
        const sessionData = await quizService.startQuiz(topicId);
        setSession(sessionData);
        setTopicName(sessionData.topicName);
        setQuestions(sessionData.questions);
        setTimeLeft(sessionData.questions.length * 60);
      } catch (ex) {
        setError('Failed to start the quiz. This topic may have no questions.');
        console.error(ex);
      } finally {
        setLoading(false);
      }
    };
    startNewQuiz();
  }, [topicId]);

  const handleSubmitQuiz = useCallback(async () => {
    if (!session) return;
    try {
      await quizService.submitQuiz(session._id, answers);
      navigate(`/results/${session._id}`);
    } catch (ex) {
      setError('Could not submit the quiz. Please check your connection.');
    }
  }, [session, answers, navigate]);

  useEffect(() => {
    if (timeLeft <= 0) {
      handleSubmitQuiz();
      return;
    }
    if (!loading && questions.length > 0) {
      const timer = setInterval(() => setTimeLeft((prevTime) => prevTime - 1), 1000);
      return () => clearInterval(timer);
    }
  }, [timeLeft, loading, questions, handleSubmitQuiz]);

  const handleOptionSelect = (questionId, optionIndex) => {
    setAnswers({ ...answers, [questionId]: optionIndex });
  };
  
  const jumpToQuestion = (index) => setCurrentQuestionIndex(index);
  const toggleBookmark = () => setBookmarks(prev => ({ ...prev, [currentQuestionIndex]: !prev[currentQuestionIndex] }));

  if (loading) return <div className="loading-message">Preparing Your Quiz...</div>;
  if (error) return <div className="error-message">{error}</div>;
  if (!session || questions.length === 0) return <div className="error-message">No questions found for this topic.</div>;

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div className="quiz-page-layout">
      <div className="quiz-main-content">
        <div className="quiz-card">
          <div className="quiz-header">
            <h3>Question {currentQuestionIndex + 1}</h3>
            <Button variant={bookmarks[currentQuestionIndex] ? 'secondary' : 'primary'} onClick={toggleBookmark}>
              {bookmarks[currentQuestionIndex] ? '★ Unbookmark' : '★ Bookmark'}
            </Button>
          </div>
          <p className="question-text">{currentQuestion.text}</p>
          <ul className="options-list">
            {currentQuestion.options.map((option, index) => (
              <li key={index}>
                <button
                  className={`option-item ${answers[currentQuestion._id] === index ? 'selected' : ''}`}
                  onClick={() => handleOptionSelect(currentQuestion._id, index)}
                >
                  {option}
                </button>
              </li>
            ))}
          </ul>
          <div className="quiz-navigation">
            <Button onClick={() => setCurrentQuestionIndex(p => p - 1)} disabled={currentQuestionIndex === 0}>Prev</Button>
            {currentQuestionIndex === questions.length - 1 ? (
               <Button onClick={handleSubmitQuiz} variant="success">Submit Quiz</Button>
            ) : (
               <Button onClick={() => setCurrentQuestionIndex(p => p + 1)}>Next</Button>
            )}
          </div>
        </div>
      </div>

      <div className="quiz-sidebar">
        <div className="question-palette-card">
          <div className="palette-header">
            <span className="progress-text" title={topicName}>{topicName}</span>
            <div className="quiz-timer">
              {Math.floor(timeLeft / 60)}:{('0' + (timeLeft % 60)).slice(-2)}
            </div>
          </div>
          <div className="palette-grid">
            {questions.map((_, index) => {
              const questionId = questions[index]._id;
              const isAttempted = answers[questionId] !== undefined;
              const isCurrent = index === currentQuestionIndex;
              const isBookmarked = bookmarks[index];
              let paletteClass = 'palette-button';
              if (isCurrent) paletteClass += ' current';
              else if (isAttempted) paletteClass += ' attempted';
              if (isBookmarked) paletteClass += ' bookmarked';
              
              return (
                <button key={index} className={paletteClass} onClick={() => jumpToQuestion(index)}>
                  {index + 1}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuizEngine;