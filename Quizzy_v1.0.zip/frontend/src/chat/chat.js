// src/chat/Chat.js

import React, { useState, useEffect, useRef } from 'react';
import * as aiQuizService from '../services/aiQuizService';
import { logAiEvent } from '../services/loggingService';
import Button from '../components/Button';
import './Chat.css';

const TYPING_SPEED = 30; // Milliseconds between each character. Lower is faster.

const Chat = () => {
    const [gameState, setGameState] = useState('topicSelection');
    const [topic, setTopic] = useState('');
    const [messages, setMessages] = useState([]);
    const [suggestions, setSuggestions] = useState([]);
    const [currentInput, setCurrentInput] = useState('');
    const [isAiThinking, setIsAiThinking] = useState(false); // True while waiting for the API response.
    const [isAiTyping, setIsAiTyping] = useState(false);   // True while simulating the typing animation.
    const [error, setError] = useState('');
    
    const messagesEndRef = useRef(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };
    useEffect(() => {
        scrollToBottom();
    }, [messages, isAiTyping]); // Auto-scroll as the AI types.

    // This useEffect hook powers the typing simulation.
    useEffect(() => {
        if (!isAiTyping) return;

        const lastMessage = messages[messages.length - 1];
        // Check if the last message is from the assistant and has more text to "type".
        if (lastMessage && lastMessage.role === 'assistant' && lastMessage.content.length < lastMessage.fullText.length) {
            const timer = setTimeout(() => {
                setMessages(prev => {
                    const newMessages = [...prev];
                    const currentMsg = newMessages[newMessages.length - 1];
                    // Append the next character to the content.
                    currentMsg.content = currentMsg.fullText.substring(0, currentMsg.content.length + 1);
                    return newMessages;
                });
            }, TYPING_SPEED);

            return () => clearTimeout(timer);
        } else {
            // Typing is finished for the current message.
            setIsAiTyping(false);
        }
    }, [messages, isAiTyping]);

    const sendMessage = async (messageHistory) => {
        setIsAiThinking(true);
        setSuggestions([]);
        setError('');
        try {
            const aiResponse = await aiQuizService.generateChatResponse({
                topic,
                messages: messageHistory,
                model: 'phi4-mini:3.8b', // <-- MODEL USED FOR CHAT
            });
            // Add a new message object with the full response hidden in `fullText`.
            setMessages(prev => [
                ...prev, 
                { role: 'assistant', content: '', fullText: aiResponse.response }
            ]);
            setSuggestions(aiResponse.suggestions);
            setIsAiTyping(true); // This will trigger the typing useEffect.
        } catch (err) {
            const errorMessage = err.message || "An unknown error occurred.";
            setMessages(prev => [...prev, { role: 'assistant', content: errorMessage, fullText: errorMessage }]);
        } finally {
            setIsAiThinking(false); // AI is done thinking, now it's "typing".
        }
    };

    const handleStartChat = () => {
        if (!topic) { setError('Please enter a topic to start about.'); return; }
        setError('');
        setMessages([]);
        setSuggestions([]);
        setGameState('chatting');
        logAiEvent('Chat Session', topic);
        // Kick-start the conversation.
        sendMessage([{ role: 'user', content: `Hello, please greet me and ask what I want to learn about ${topic}.` }]);
    };

    const handleSubmitMessage = (e) => {
        e.preventDefault();
        const trimmedInput = currentInput.trim();
        if (!trimmedInput || isAiThinking || isAiTyping) return;
        const newMessages = [...messages, { role: 'user', content: trimmedInput }];
        setMessages(newMessages);
        setCurrentInput('');
        sendMessage(newMessages);
    };

    const handleSuggestionClick = (text) => {
        if (isAiThinking || isAiTyping) return;
        const newMessages = [...messages, { role: 'user', content: text }];
        setMessages(newMessages);
        sendMessage(newMessages);
    };

    if (gameState === 'topicSelection') {
        return (
            <div className="chat-page-container">
                <div className="chat-topic-selector">
                    <h1>AI Tutor Chat</h1>
                    <p>Choose a topic to start a conversation with your personal AI tutor. The tutor will stick to the topic and help you learn.</p>
                    <div className="chat-form">
                        <input type="text" value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="e.g., The Solar System, Python Basics"/>
                        <Button onClick={handleStartChat} disabled={isAiThinking}>{isAiThinking ? 'Starting...' : 'Start Chatting'}</Button>
                    </div>
                    {error && <p className="import-error" style={{marginTop: '1rem'}}>{error}</p>}
                </div>
            </div>
        );
    }

    const isInputDisabled = isAiThinking || isAiTyping;

    return (
        <div className="chat-page-container">
            <div className="chat-window">
                <div className="chat-header">
                    <h3>AI Tutor: {topic}</h3>
                    <Button variant="secondary" onClick={() => setGameState('topicSelection')}>New Topic</Button>
                </div>
                <div className="chat-messages">
                    {messages.map((msg, index) => (
                        <div key={index} className={`message ${msg.role}`}>
                            <span className={isAiTyping && index === messages.length - 1 ? 'message-content' : ''}>
                                {msg.content}
                            </span>
                        </div>
                    ))}
                    {isAiThinking && (
                        <div className="message assistant typing">Thinking...</div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
                
                {!isInputDisabled && suggestions.length > 0 && (
                    <div className="suggestions">
                        {suggestions.slice(0, 3).map((text, index) => (
                            <button key={index} className="suggestion-btn" onClick={() => handleSuggestionClick(text)}>{text}</button>
                        ))}
                    </div>
                )}

                <form onSubmit={handleSubmitMessage} className="chat-input-form">
                    <input type="text" value={currentInput} onChange={(e) => setCurrentInput(e.target.value)} placeholder="Ask a question..." disabled={isInputDisabled} />
                    <Button type="submit" disabled={isInputDisabled}>{isAiThinking ? '...' : 'Send'}</Button>
                </form>
            </div>
        </div>
    );
};

export default Chat;