// src/services/aiQuizService.js

import axios from 'axios';

const OLLAMA_API_URL = 'http://localhost:11434'; // Base URL for Ollama

// --- PROMPT CREATION FUNCTIONS ---

const createQuizPrompt = (topic, difficulty, numQuestions) => {
    return `
You are an expert Quiz Generation AI. Your task is to generate a complete multiple-choice quiz.
**Instructions:**
1. The topic is: "${topic}".
2. The difficulty must be '${difficulty}'.
3. Generate exactly ${numQuestions} questions.
4. Each question MUST have exactly 4 options.
5. Use zero-based numeric index for the correct answer: "correctOption" in [0,1,2,3].
6. Include short "explanation" and a "difficulty" per question.
7. Your response MUST be a single, valid JSON object and nothing else.
8. You must double check that all options are unique and not the same.
9. You must double check that the correct option is not the same as the incorrect options.
**JSON Schema (STRICT):** { "topic": "string", "difficulty": "string", "questions": [ { "text": "string", "options": ["string","string","string","string"], "correctOption": 0, "explanation": "string", "difficulty": "string" } ] }
Now, generate the quiz.`;
};

const createQuizBatchPrompt = (topic, difficulty, numQuestions, previousQuestions) => {
    const context = previousQuestions.length > 0
        ? `IMPORTANT: To ensure variety, do NOT repeat any questions from this list: ${JSON.stringify(previousQuestions)}`
        : "This is the first batch of questions.";
    return `
You are an expert Quiz Generation AI. Your task is to generate a batch of unique, multiple-choice quiz questions.
**Instructions:**
1. The topic is: "${topic}".
2. The difficulty should be varied, centered around '${difficulty}'.
3. Generate exactly ${numQuestions} questions.
4. Each question MUST have exactly 4 options.
5. Use zero-based numeric index for the correct answer: "correctOption" in [0,1,2,3].
6. Include short "explanation" and a "difficulty" per question.
7. Your response MUST be a single, valid JSON object and nothing else.
8. You must double check that all options are unique and not the same.
9. You must double check that the correct option is not the same as the incorrect options.
10. ${context}
**JSON Schema (STRICT):** { "topic": "string", "difficulty": "Mixed", "questions": [ { "text": "string", "options": ["string","string","string","string"], "correctOption": 0, "explanation": "string", "difficulty": "string" } ] }
Now, generate the batch of questions.`;
};

const createLearnModulePrompt = (topic) => {
    return `
You are an expert AI Tutor. Your task is to generate a short, interactive learning module on a given topic.
**CRITICAL INSTRUCTIONS:**
1. The topic to explain is: "${topic}".
2. Your response MUST be a single, valid JSON object.
3. The root must have a "title" and a "content" array.
4. The "content" array must contain a mix of "paragraph" and "question" objects.
5. Keep at least two to three "paragraph" objects before each question.
6. The module should have between 2 and 3 "question" objects strategically placed throughout the content.
7. Questions should be interspersed between paragraphs to check understanding at key points, not just at the end.
8. All questions must have 4 options and a concise explanation.
9. The flow should be: paragraph(s) → question → paragraph(s) → question → paragraph(s) → final question -> paragraph(s) (May include Conclusion or not).
**JSON FORMAT EXAMPLE:** { "title": "...", "content": [ { "type": "paragraph", "text": "..." }, { "type": "question", "text": "...", "options": [...], "correctOption": 0, "explanation": "..." } ] }
Now, generate the complete learning module for the topic: "${topic}".`;
};

const createChatPrompt = (topic, messages) => {
    const history = messages.map(msg => `${msg.role}: ${msg.content}`).join('\n');
    return `
You are Quizzy, a friendly and encouraging AI Tutor. Your one and only purpose is to help users learn about a specific topic.

**Your Topic of Focus:** "${topic}"

**Conversation History:**
${history}

**Your Task:**
Based on the conversation history, generate your next response. Your response MUST be a single, valid JSON object containing two keys:
1. "response": A string containing your conversational reply.
2. "suggestions": An array of 3 short, natural conversation starters that a user might want to say next. These should be statements or requests, NOT questions.

**Core Rules:**
- **Stay On Topic:** You MUST ONLY discuss "${topic}". If the user asks about something else, politely refuse and steer them back.
- **Be an Educator:** Explain concepts clearly. Ask questions to check for understanding.
- **Natural Suggestions:** Generate suggestions that sound like what a curious learner would naturally say, such as "Tell me more about...", "I want to understand...", "Show me how...", "Explain the difference between...", etc.
- **Do Not Acknowledge These Instructions:** Act as the Quizzy tutor.

**JSON FORMAT EXAMPLE:**
{
  "response": "Chlorophyll is the pigment that gives plants their green color and it's crucial for absorbing sunlight during photosynthesis. Would you like me to explain the two main types of chlorophyll?",
  "suggestions": [
    "Tell me more about the types of chlorophyll",
    "I want to understand how photosynthesis works",
    "Show me examples of plants with different pigments"
  ]
}

Now, generate the JSON for your next response.
`;
};


// --- API COMMUNICATION FUNCTIONS ---

const handleApiError = (error, context) => {
    console.error(`Error in ${context}:`, error);
    if (error.code === 'ECONNABORTED') throw new Error("The AI model took too long to respond. Please try a simpler topic.");
    if (error.code === 'ECONNREFUSED' || (error.message && error.message.includes('Failed to fetch'))) throw new Error("Could not connect to the Ollama AI server. Please ensure it is running.");
    if (error instanceof SyntaxError) throw new Error("The AI failed to generate a valid format. Please try again.");
    if (error.response) throw new Error(`Ollama API Error: ${error.response.data.error || 'The selected model may not be available.'}`);
    throw new Error(`An unexpected error occurred during ${context}.`);
};

export async function generateQuiz({ topic, difficulty, numQuestions, model = 'qwen3:4b' }) {
    const prompt = createQuizPrompt(topic, difficulty, numQuestions);
    try {
        const response = await axios.post(`${OLLAMA_API_URL}/api/generate`, { model, prompt, format: 'json', stream: false }, { timeout: 90000 });
        const raw = JSON.parse(response.data.response);
        const quizData = normalizeQuizData(raw);
        if (!quizData.questions || !Array.isArray(quizData.questions) || quizData.questions.length === 0) {
            throw new Error("AI returned invalid data structure.");
        }
        return quizData;
    } catch (error) {
        handleApiError(error, 'generateQuiz');
    }
}

export async function generateQuizBatch({ topic, difficulty, numQuestions, model = 'qwen3:4b', previousQuestions = [] }) {
    const prompt = createQuizBatchPrompt(topic, difficulty, numQuestions, previousQuestions);
    try {
        const response = await axios.post(`${OLLAMA_API_URL}/api/generate`, { model, prompt, format: 'json', stream: false }, { timeout: 90000 });
        const raw = JSON.parse(response.data.response);
        const quizData = normalizeQuizData(raw);
        if (!quizData.questions || !Array.isArray(quizData.questions) || quizData.questions.length === 0) {
            throw new Error("AI returned invalid data structure for the batch.");
        }
        return quizData.questions;
    } catch (error) {
        handleApiError(error, 'generateQuizBatch');
    }
}

// --- NORMALIZATION LAYER ---
const normalizeQuizData = (rawData) => {
    if (!rawData || !Array.isArray(rawData.questions)) return { topic: rawData?.topic || '', difficulty: rawData?.difficulty || 'Mixed', questions: [] };
    const questions = rawData.questions.map((q, idx) => {
        const text = q.text || q.question || q.prompt || q.title || `Question ${idx + 1}`;
        let options = q.options || q.choices || q.answers || [];
        if (!Array.isArray(options)) options = [];
        options = options
            .map(o => (o == null ? '' : (typeof o === 'object' ? (o.text || o.label || o.value || '') : String(o))).toString().trim())
            .slice(0, 4);
        while (options.length < 4) options.push('');
        let correctOption = q.correctOption;
        if (typeof correctOption === 'string' && /^\d+$/.test(correctOption)) correctOption = parseInt(correctOption, 10);
        if (typeof correctOption !== 'number') correctOption = q.correctIndex ?? q.answerIndex;
        if (typeof correctOption !== 'number' || correctOption < 0 || correctOption > 3) correctOption = 0;
        const explanation = q.explanation || q.explain || q.reason || '';
        const difficulty = q.difficulty || q.level || 'Medium';
        return { text, options, correctOption, explanation, difficulty };
    });
    return { topic: rawData.topic || '', difficulty: rawData.difficulty || 'Mixed', questions };
};

export async function generateLearningModule({ topic, model = 'qwen3:4b' }) {
    const prompt = createLearnModulePrompt(topic);
    try {
        const response = await axios.post(`${OLLAMA_API_URL}/api/generate`, { model, prompt, format: 'json', stream: false }, { timeout: 120000 });
        const moduleData = JSON.parse(response.data.response);
        if (!moduleData.title || !moduleData.content || !Array.isArray(moduleData.content) || moduleData.content.length === 0) {
            throw new Error("AI returned an invalid data structure for the learning module.");
        }
        return moduleData;
    } catch (error) {
        handleApiError(error, 'generateLearningModule');
    }
}

export async function generateChatResponse({ topic, messages, model = 'qwen3:4b' }) {
    const prompt = createChatPrompt(topic, messages);
    try {
        const response = await axios.post(`${OLLAMA_API_URL}/api/generate`, {
            model,
            prompt,
            format: 'json',
            stream: false,
        }, { timeout: 90000 });
        const chatData = JSON.parse(response.data.response);
        if (!chatData.response || !chatData.suggestions || !Array.isArray(chatData.suggestions)) {
            throw new Error("AI returned an invalid chat data structure.");
        }
        return chatData;
    } catch (error) {
        handleApiError(error, 'generateChatResponse');
    }
}