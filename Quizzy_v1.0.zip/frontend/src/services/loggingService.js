// src/services/loggingService.js

import axios from 'axios';
import { getCurrentUser } from './authService';

// This service calls the '/api/admin' route, so we define it here.
const API_URL = 'http://localhost:5000/api/admin';

/**
 * Logs an AI generation event to the database for admin review.
 * This is designed to be a "fire and forget" call; we don't need to wait for the response.
 * 
 * @param {string} featureUsed - The name of the feature that was used (e.g., 'Quiz Generator', 'Learn Module').
 * @param {string} topicPrompt - The topic the user provided.
 */
export const logAiEvent = (featureUsed, topicPrompt) => {
    try {
        const user = getCurrentUser();
        // Only send a log if a user is logged in.
        if (user && user.id) {
            axios.post(`${API_URL}/log-event`, {
                userId: user.id,
                featureUsed: featureUsed,
                topicPrompt: topicPrompt,
            });
            // We don't use 'await' here because the user's experience shouldn't
            // be delayed by the logging process.
        }
    } catch (error) {
        // We also don't show an error to the user if logging fails,
        // as it's a non-critical background task.
        console.error("Failed to log AI event:", error);
    }
};