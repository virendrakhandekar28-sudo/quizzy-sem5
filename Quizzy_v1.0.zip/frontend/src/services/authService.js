// src/services/authService.js

import axios from 'axios';
import { jwtDecode } from 'jwt-decode';

// The base URL for your backend API.
// In a real application, this should be in an environment variable (.env file).
const API_URL = 'http://localhost:5000/api/auth';
const TOKEN_KEY = 'quizzy_token'; // Key for storing the token in localStorage

/**
 * Sends registration data to the backend.
 * @param {string} name - The user's full name.
 * @param {string} email - The user's email.
 * @param {string} password - The user's password.
 */
export async function register(name, email, password) {
  // We use '/users/register' assuming a different controller for user management
  return axios.post('http://localhost:5000/api/users/register', { name, email, password });
}

/**
 * Sends login credentials to the backend and stores the received JWT.
 * @param {string} email - The user's email.
 * @param {string} password - The user's password.
 * @returns {object} The decoded user object from the token.
 */
export async function login(email, password) {
  const { data: jwt } = await axios.post(`${API_URL}/login`, { email, password });
  localStorage.setItem(TOKEN_KEY, jwt);
  return getCurrentUser(); // Return the user object after login
}

/**
 * Removes the JWT from localStorage, effectively logging the user out.
 */
export function logout() {
  localStorage.removeItem(TOKEN_KEY);
}

/**
 * Retrieves the JWT from localStorage.
 * @returns {string|null} The stored JWT or null if it doesn't exist.
 */
export function getJwt() {
  return localStorage.getItem(TOKEN_KEY);
}

/**
 * Decodes the JWT from localStorage to get user information.
 * @returns {object|null} The decoded user object or null if no token exists.
 */
export function getCurrentUser() {
  try {
    const jwt = localStorage.getItem(TOKEN_KEY);
    return jwtDecode(jwt);
  } catch (ex) {
    // If the token doesn't exist or is invalid, return null
    return null;
  }
}

// Export as a default object for consistency if you prefer that pattern
const authService = {
  register,
  login,
  logout,
  getCurrentUser,
  getJwt,
};

export default authService;