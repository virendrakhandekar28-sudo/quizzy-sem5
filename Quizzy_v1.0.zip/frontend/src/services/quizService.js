// src/services/quizService.js

import axios from 'axios';
import { getJwt } from './authService';

const API_URL = 'http://localhost:5000/api/quizzes';

/**
 * Fetches the list of all available quiz topics from the backend.
 * @returns {Promise<Array>} A promise that resolves to an array of topic objects.
 */
const authConfig = () => {
  const token = getJwt();
  return token ? { headers: { Authorization: `Bearer ${token}` } } : {};
};

export async function getTopics() {
  const { data } = await axios.get(`${API_URL}/topics`, authConfig());
  return data;
}

/**
 * Fetches the questions for a specific quiz topic.
 * @param {string} topicId - The ID of the selected topic.
 * @returns {Promise<Object>} A promise that resolves to a quiz session object with questions.
 */
export async function startQuiz(topicId) {
  const { data } = await axios.post(`${API_URL}/start`, { topicId }, authConfig());
  return data;
}

/**
 * Submits the user's answers for a quiz session to the backend for scoring.
 * @param {string} sessionId - The ID of the quiz session.
 * @param {object} answers - An object containing question IDs and selected answers.
 * @returns {Promise<Object>} A promise that resolves to the quiz result.
 */
export async function submitQuiz(sessionId, answers) {
  const { data } = await axios.post(`${API_URL}/submit`, { sessionId, answers }, authConfig());
  return data;
}

/**
 * Fetches the detailed results of a specific quiz session.
 * @param {string} sessionId - The ID of the quiz session.
 * @returns {Promise<Object>} A promise that resolves to the result object.
 */
export async function getResults(sessionId) {
  const { data } = await axios.get(`${API_URL}/results/${sessionId}`, authConfig());
  return data;
}

/**
 * Fetches the current user's entire quiz history.
 * @returns {Promise<Array>} A promise that resolves to an array of past quiz results.
 */
export async function getUserHistory() {
  const { data } = await axios.get(`${API_URL}/history`, authConfig());
  return data;
}

// --- NEW FUNCTION TO SAVE AI QUIZ RESULTS ---
/**
 * Saves the result of an AI-generated quiz to the database.
 * @param {object} resultData - The quiz result data.
 * @param {string} resultData.topicName - The actual topic of the AI quiz.
 * @param {number} resultData.score - The user's score.
 * @param {number} resultData.totalQuestions - The total number of questions.
 * @returns {Promise<object>} The server's response.
 */
export async function saveGeneratedQuizResult(resultData) {
  return axios.post(`${API_URL}/save-generated`, resultData, authConfig());
}

const quizService = {
  getTopics,
  startQuiz,
  submitQuiz,
  getResults,
  getUserHistory,
  saveGeneratedQuizResult,
};

export default quizService;