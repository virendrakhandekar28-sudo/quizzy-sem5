// src/services/leaderboardService.js

import axios from 'axios';

const API_URL = 'http://localhost:5000/api/leaderboard';

/**
 * Updates the user's cumulative score after a question is answered or skipped.
 * @param {string} status - The result of the question ('correct', 'incorrect', 'skipped').
 * @returns {Promise<object>} The server's response.
 */
export async function updateCumulativeScore(status) {
  return axios.put(`${API_URL}/update-score`, { status });
}

/**
 * Fetches the all-time leaderboard data.
 * @returns {Promise<Array>} A promise that resolves to an array of leaderboard entries.
 */
export async function getLeaderboard() {
  const { data } = await axios.get(`${API_URL}/`);
  return data;
}

const leaderboardService = {
  updateCumulativeScore,
  getLeaderboard,
};

export default leaderboardService;