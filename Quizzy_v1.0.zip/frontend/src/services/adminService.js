// src/services/adminService.js

import axios from 'axios';

// The base URL for all admin-specific API endpoints.
const API_URL = 'http://localhost:5000/api/admin';

/**
 * Fetches dashboard statistics.
 */
export async function getDashboardStats() {
  const { data } = await axios.get(`${API_URL}/stats`);
  return data;
}

/**
 * Fetches a list of all users.
 */
export async function getAllUsers() {
  const { data } = await axios.get(`${API_URL}/users`);
  return data;
}

/**
 * Blocks a user's account.
 */
export async function blockUser(userId) {
  return axios.post(`${API_URL}/users/${userId}/block`);
}

/**
 * Unblocks a user's account.
 */
export async function unblockUser(userId) {
  return axios.post(`${API_URL}/users/${userId}/unblock`);
}

/**
 * Fetches the AI generation logs.
 */
export async function getAiUsageLogs() {
    const { data } = await axios.get(`${API_URL}/logs`);
    return data;
}

/**
 * Fetches the full user leaderboard for admin management.
 */
export async function getFullLeaderboard() {
    const { data } = await axios.get(`${API_URL}/leaderboard`);
    return data;
}

/**
 * Resets a specific user's cumulative score to zero.
 */
export async function resetUserScore(userId) {
    return axios.post(`${API_URL}/leaderboard/reset/${userId}`);
}


// --- NEW FUNCTIONS FOR TOPIC & QUESTION MANAGEMENT ---

/**
 * Fetches all database topics along with their question counts for the admin panel.
 * @returns {Promise<Array>} A promise that resolves to an array of topic objects.
 */
export async function getAdminTopics() {
    const { data } = await axios.get(`${API_URL}/topics`);
    return data;
}

/**
 * Adds a new topic to the database.
 * @param {object} topicData - An object with { name, description }.
 * @returns {Promise<object>} The newly created topic object.
 */
export async function addAdminTopic(topicData) {
    const { data } = await axios.post(`${API_URL}/topics`, topicData);
    return data;
}

/**
 * Fetches all questions for a specific topic ID.
 * @param {number} topicId - The ID of the topic.
 * @returns {Promise<Array>} A promise that resolves to an array of question objects.
 */
export async function getQuestionsForTopic(topicId) {
    const { data } = await axios.get(`${API_URL}/topics/${topicId}/questions`);
    return data;
}

/**
 * Adds a new question to a specific topic.
 * @param {object} questionData - Object with all question details.
 * @returns {Promise<object>} The server's response.
 */
export async function addAdminQuestion(questionData) {
    const { data } = await axios.post(`${API_URL}/questions`, questionData);
    return data;
}

// Consolidate all functions into a single export object for consistency.
const adminService = {
  getDashboardStats,
  getAllUsers,
  blockUser,
  unblockUser,
  getAiUsageLogs,
  getFullLeaderboard,
  resetUserScore,
  getAdminTopics,      // <-- NEW
  addAdminTopic,       // <-- NEW
  getQuestionsForTopic,// <-- NEW
  addAdminQuestion,    // <-- NEW
};

export default adminService;