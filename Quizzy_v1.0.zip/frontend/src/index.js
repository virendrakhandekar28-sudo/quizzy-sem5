// src/index.js

import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import axios from 'axios'; // Import axios here

import App from './App';
import { getJwt } from './services/authService';
import './assets/global.css';

// --- ROBUST AXIOS INTERCEPTOR ---
// This code will run before every single Axios request in your application.
axios.interceptors.request.use(
  config => {
    // Define just the host of YOUR backend API
    const backendApiHost = 'http://localhost:5000';

    // Check if the request URL is targeting your backend API host.
    // This is more flexible than checking the full path.
    if (config.url.startsWith(backendApiHost) || config.url.startsWith('/api')) {
      const token = getJwt();
      if (token) {
        // If a token exists, add it to the request header
        config.headers['x-auth-token'] = token;
      }
    }
    // Return the modified config to proceed with the request
    return config;
  },
  error => {
    // Do something with request error
    return Promise.reject(error);
  }
);

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);