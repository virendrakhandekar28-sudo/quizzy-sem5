// src/endless/EndlessQuiz.js

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import * as aiQuizService from '../services/aiQuizService';
import * as leaderboardService from '../services/leaderboardService';
import * as authService from '../services/authService';
import Button from '../components/Button';
import './EndlessQuiz.css';

const BATCH_SIZE = 5;
const CACHE_KEY = 'endlessQuizNextBatch';

const EndlessQuiz = () => {
    const [gameState, setGameState] = useState('setup');
    const [topic, setTopic] = useState('');
    const [currentBatch, setCurrentBatch] = useState([]);
    const [questionIndexInBatch, setQuestionIndexInBatch] = useState(0);
    const [isFetching, setIsFetching] = useState(false);
    const [previousQuestions, setPreviousQuestions] = useState([]);
    const [isCorrect, setIsCorrect] = useState(false);
    const [sessionScore, setSessionScore] = useState(0);
    const [questionCount, setQuestionCount] = useState(0);
    const [countdown, setCountdown] = useState(0);
    const [leaderboard, setLeaderboard] = useState([]);
    const [currentUserRank, setCurrentUserRank] = useState(null);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    // Ensure AI questions conform to expected shape
    const normalizeQuestions = (rawQuestions) => {
        if (!Array.isArray(rawQuestions)) return [];
        return rawQuestions.map((q, idx) => {
            const text = q.text || q.question || q.prompt || q.title || `Question ${idx + 1}`;
            let options = q.options || q.choices || q.answers || [];
            if (Array.isArray(options)) {
                options = options.map(opt => {
                    if (opt == null) return '';
                    if (typeof opt === 'object') {
                        return String(opt.text || opt.label || opt.value || '').trim();
                    }
                    return String(opt).trim();
                });
            } else {
                options = [];
            }
            // Enforce exactly 4 options
            if (options.length > 4) options = options.slice(0, 4);
            if (options.length < 4) {
                const pads = new Array(4 - options.length).fill('');
                options = [...options, ...pads];
            }
            let correctOption = q.correctOption;
            if (typeof correctOption === 'string' && /^\d+$/.test(correctOption)) {
                correctOption = parseInt(correctOption, 10);
            }
            if (typeof correctOption !== 'number') {
                correctOption = q.correctIndex ?? q.answerIndex;
            }
            if (typeof correctOption === 'number') {
                if (!(correctOption >= 0 && correctOption < 4)) {
                    correctOption = undefined;
                }
            }
            const explanation = q.explanation || q.explain || q.reason || '';
            const difficulty = q.difficulty || q.level || 'Medium';
            return { ...q, text, options, correctOption, explanation, difficulty };
        });
    };

    const fetchAndStoreNextBatch = async () => {
        if (isFetching) return false;
        setIsFetching(true);
        try {
            const lastQuestions = previousQuestions.slice(-3);
            const questions = await aiQuizService.generateQuizBatch({
                topic,
                difficulty: 'Medium',
                numQuestions: BATCH_SIZE,
                model: 'qwen3:4b',
                previousQuestions: lastQuestions,
            });
            const normalized = normalizeQuestions(questions);
            const cachePayload = { topic, questions: normalized, generatedAt: Date.now() };
            localStorage.setItem(CACHE_KEY, JSON.stringify(cachePayload));
            return true;
        } catch (err) {
            setError(err.message);
            return false;
        } finally {
            setIsFetching(false);
        }
    };

    const handleStart = () => {
        if (!topic) { setError('Please provide a topic to start.'); return; }
        setError('');
        setSessionScore(0);
        setQuestionCount(0);
        setPreviousQuestions([]);
        const cachedBatchJSON = localStorage.getItem(CACHE_KEY);
        if (cachedBatchJSON) {
            console.log("Starting instantly with cached batch.");
            const cached = JSON.parse(cachedBatchJSON);
            const cacheIsValid = cached && cached.topic === topic && Array.isArray(cached.questions) && cached.questions.length > 0;
            if (cacheIsValid) {
                setCurrentBatch(normalizeQuestions(cached.questions));
                setGameState('playing');
                localStorage.removeItem(CACHE_KEY);
                fetchAndStoreNextBatch();
            } else {
                // Ignore stale cache from a different topic
                localStorage.removeItem(CACHE_KEY);
                console.log("Cached batch doesn't match topic. Fetching initial batch.");
                setGameState('waiting');
                const fetchInitialBatch = async () => {
                    const success = await fetchAndStoreNextBatch();
                    if (success) {
                        const newBatchJSON = localStorage.getItem(CACHE_KEY);
                        const payload = JSON.parse(newBatchJSON);
                        setCurrentBatch(normalizeQuestions(payload?.questions || []));
                        localStorage.removeItem(CACHE_KEY);
                        setGameState('playing');
                        fetchAndStoreNextBatch();
                    } else {
                        setGameState('setup');
                    }
                };
                fetchInitialBatch();
            }
        } else {
            console.log("No cache. Fetching initial batch.");
            setGameState('waiting');
            const fetchInitialBatch = async () => {
                const success = await fetchAndStoreNextBatch();
                if (success) {
                    const newBatchJSON = localStorage.getItem(CACHE_KEY);
                    const payload = JSON.parse(newBatchJSON);
                    setCurrentBatch(normalizeQuestions(payload?.questions || []));
                    localStorage.removeItem(CACHE_KEY);
                    setGameState('playing');
                    fetchAndStoreNextBatch();
                } else {
                    setGameState('setup');
                }
            };
            fetchInitialBatch();
        }
    };
    
    useEffect(() => {
        if (countdown > 0) {
            const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
            return () => clearTimeout(timer);
        }
        if (countdown === 0 && gameState === 'countdown') {
            const payload = JSON.parse(localStorage.getItem(CACHE_KEY));
            const nextBatch = payload?.questions || [];
            setCurrentBatch(normalizeQuestions(nextBatch));
            localStorage.removeItem(CACHE_KEY);
            setQuestionIndexInBatch(0);
            setGameState('playing');
            fetchAndStoreNextBatch();
        }
    }, [countdown, gameState]);

    const handleAnswer = async (selectedIndex) => {
        const correct = currentQuestion.correctOption === selectedIndex;
        setIsCorrect(correct);
        try {
            await leaderboardService.updateCumulativeScore(correct ? 'correct' : 'incorrect');
            setSessionScore(prev => prev + (correct ? 5 : -3));
            setQuestionCount(prev => prev + 1);
            setPreviousQuestions(prev => [...prev, currentQuestion.text]);
            setGameState('feedback');
        } catch (err) {
            setError('Connection to database lost. Ending run.');
            handleEndRun();
        }
    };

    const handleSkip = async () => {
        try {
            await leaderboardService.updateCumulativeScore('skipped');
            setSessionScore(prev => prev - 1);
            setQuestionCount(prev => prev + 1);
            setPreviousQuestions(prev => [...prev, currentQuestion.text]);
            handleNext();
        } catch (err) {
            setError('Connection to database lost. Ending run.');
            handleEndRun();
        }
    };

    const handleNext = () => {
        if (questionIndexInBatch < currentBatch.length - 1) {
            setQuestionIndexInBatch(prev => prev + 1);
            setGameState('playing');
        } else {
            const nextBatchJSON = localStorage.getItem(CACHE_KEY);
            if (nextBatchJSON) {
                setCountdown(3);
                setGameState('countdown');
            } else {
                setGameState('waiting');
            }
        }
    };

    useEffect(() => {
        if (gameState === 'waiting') {
            const checkCache = setInterval(() => {
                if (localStorage.getItem(CACHE_KEY)) {
                    clearInterval(checkCache);
                    handleNext();
                }
            }, 1000);
            return () => clearInterval(checkCache);
        }
    }, [gameState]);

    const handleEndRun = async () => {
        try {
            const { topPlayers, currentUserRank } = await leaderboardService.getLeaderboard();
            setLeaderboard(topPlayers);
            setCurrentUserRank(currentUserRank);
        } catch (err) {
            setError('Could not fetch leaderboard data.');
        } finally {
            setGameState('gameOver');
        }
    };

    const handleViewLeaderboard = async () => {
        setError('');
        setGameState('waiting');
        await handleEndRun();
    };
    
    if (gameState === 'setup') {
        return (
            <div className="endless-container topic-selector">
                <h1>Endless Quiz</h1>
                <p>Test your knowledge in a race against the AI. Your total score across all runs will be added to the leaderboard!</p>
                <input type="text" value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="Enter a topic, e.g., 'World Capitals'"/>
                {error && <p className="import-error" style={{marginTop: '1rem'}}>{error}</p>}
                <div className="topic-selector-actions">
                    <Button onClick={handleStart} disabled={isFetching}>{isFetching ? 'Preparing...' : 'Start Run'}</Button>
                    <Button variant="secondary" onClick={handleViewLeaderboard}>View Leaderboard</Button>
                </div>
            </div>
        );
    }

    if (gameState === 'gameOver') {
        const user = authService.getCurrentUser();
        const userIsInTopList = leaderboard.some(p => p.name === user.name);
        return (
            <div className="endless-container game-over-screen">
                {questionCount > 0 ? <h1>Run Finished!</h1> : <h1>All-Time Leaderboard</h1>}
                {error && <p className="import-error" style={{marginBottom: '1rem'}}>{error}</p>}
                {questionCount > 0 && (
                    <div className="final-score-display">
                        <span className="label">Session Score</span>
                        <span className="score">{sessionScore}</span>
                    </div>
                )}
                <table className="leaderboard-table">
                    <thead><tr><th className="rank">#</th><th>Player</th><th className="score">Total Score</th></tr></thead>
                    <tbody>
                        {leaderboard.map((entry, index) => (
                            <tr key={index}><td className="rank">{index + 1}</td><td>{entry.name}</td><td className="score">{entry.total_score}</td></tr>
                        ))}
                    </tbody>
                    {currentUserRank && !userIsInTopList && (
                        <tfoot>
                            <tr>
                                <td className="rank">{currentUserRank.rank}</td>
                                <td>{user.name} (You)</td>
                                <td className="score">{currentUserRank.total_score}</td>
                            </tr>
                        </tfoot>
                    )}
                </table>
                <div className="game-over-actions">
                    {topic && <Button variant="primary" onClick={handleStart}>Play Again on "{topic}"</Button>}
                    <Button variant="secondary" onClick={() => navigate('/dashboard')}>Back to Dashboard</Button>
                </div>
            </div>
        );
    }
    
    if (gameState === 'waiting') {
        return (
            <div className="endless-container">
                <div className="overlay" style={{ position: 'relative' }}>
                    <div className="retry-spinner"></div>
                    <p className="retry-text">{currentBatch.length === 0 ? 'Preparing your first set of questions...' : 'Generating the next set of questions...'}</p>
                </div>
            </div>
        );
    }
    
    const currentQuestion = currentBatch[questionIndexInBatch];
    if (!currentQuestion) {
        return <div className="loading-message">Loading Question...</div>;
    }
    
    const isLastQuestionInBatch = questionIndexInBatch === currentBatch.length - 1;
    const isNextBatchReady = !!localStorage.getItem(CACHE_KEY);

    return (
        <div className="endless-container">
            {gameState === 'countdown' && (
                <div className="overlay"><div className="countdown-number" key={countdown}>{countdown}</div></div>
            )}
            <div className="game-header">
                <span className="score">Session Score: {sessionScore}</span>
                <span className={`difficulty-tag difficulty-${currentQuestion.difficulty}`}>{currentQuestion.difficulty}</span>
                <span className="question-count">Question: {questionCount + 1}</span>
            </div>
            <div className="question-area">
                <h2>{currentQuestion.text}</h2>
                <div className="options-grid">
                    {currentQuestion.options.map((option, index) => (
                        <button key={index} className="option-button" onClick={() => handleAnswer(index)} disabled={gameState !== 'playing'}>{option}</button>
                    ))}
                </div>
                {gameState === 'playing' && (
                    <div className="quiz-actions">
                        <Button variant="secondary" onClick={handleSkip}>Skip (-1 Point)</Button>
                        <Button variant="danger" onClick={handleEndRun}>End Run & See Leaderboard</Button>
                    </div>
                )}
            </div>
            {gameState === 'feedback' && (
                <div className={`feedback-area ${isCorrect ? 'feedback-correct' : 'feedback-incorrect'}`}>
                    <h3>{isCorrect ? 'Correct!' : 'Incorrect!'}</h3>
                    <p>{currentQuestion.explanation}</p>
                    <div style={{ marginTop: '1rem', display: 'flex', justifyContent: 'space-between' }}>
                        {isLastQuestionInBatch ? (
                            <Button onClick={handleNext} disabled={isFetching && !isNextBatchReady}>
                                {isFetching && !isNextBatchReady ? 'Preparing...' : 'Next Question'}
                            </Button>
                        ) : (
                            <Button onClick={handleNext}>Next Question</Button>
                        )}
                        <Button variant="danger" onClick={handleEndRun}>End Run & See Leaderboard</Button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default EndlessQuiz;