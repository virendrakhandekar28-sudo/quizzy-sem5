// backend/server.js

require('dotenv').config();
const express = require('express');
const cors = require('cors');

// --- Import Routes ---
const usersRoutes = require('./routes/users');
const authRoutes = require('./routes/auth');
const quizRoutes = require('./routes/quizzes');
const adminRoutes = require('./routes/admin');
const leaderboardRoutes = require('./routes/leaderboard');

const app = express();
const PORT = process.env.PORT || 5000;

// --- Middleware ---
app.use(cors());
app.use(express.json());

// --- Use Routes ---
app.use('/api/users', usersRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/quizzes', quizRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/leaderboard', leaderboardRoutes);

// --- Basic Welcome Route ---
app.get('/', (req, res) => {
    res.send('Welcome to the Quizzy Backend API!');
});

// --- Start the Server ---
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});