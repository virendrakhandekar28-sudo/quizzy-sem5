// backend/routes/leaderboard.js

const express = require('express');
const db = require('../database');
const auth = require('../middleware/auth');
const router = express.Router();

// Route: PUT /api/leaderboard/update-score
router.put('/update-score', auth, (req, res) => {
    const { status } = req.body;
    const userId = req.user.id;

    if (!['correct', 'incorrect', 'skipped'].includes(status)) {
        return res.status(400).send('A valid status (correct, incorrect, skipped) is required.');
    }

    let scoreChange;
    switch (status) {
        case 'correct': scoreChange = 5; break;
        case 'incorrect': scoreChange = -3; break;
        case 'skipped': scoreChange = -1; break;
        default: scoreChange = 0;
    }

    const sql = `
        INSERT INTO cumulative_leaderboard (user_id, total_score, total_questions_answered, last_played_at)
        VALUES (?, ?, 1, CURRENT_TIMESTAMP)
        ON CONFLICT(user_id) DO UPDATE SET
            total_score = total_score + ?,
            total_questions_answered = total_questions_answered + 1,
            last_played_at = CURRENT_TIMESTAMP
    `;

    db.run(sql, [userId, scoreChange, scoreChange], function(err) {
        if (err) {
            console.error(err.message);
            return res.status(500).send('Server error updating score.');
        }
        res.status(200).json({ message: 'Score updated successfully.' });
    });
});

// Route: GET /api/leaderboard - Fetches the leaderboard AND the current user's rank.
router.get('/', auth, (req, res) => {
    const userId = req.user.id;

    // Query 1: Get the top 20 players for the main leaderboard display.
    const topPlayersSql = `
        SELECT 
            u.name, 
            cl.total_score, 
            cl.total_questions_answered
        FROM cumulative_leaderboard cl
        JOIN users u ON cl.user_id = u.id
        ORDER BY cl.total_score DESC
        LIMIT 20
    `;

    // Query 2: Find the specific rank of the user making the request.
    const currentUserRankSql = `
        SELECT * FROM (
            SELECT 
                user_id,
                total_score,
                RANK() OVER (ORDER BY total_score DESC) as rank
            FROM cumulative_leaderboard
        )
        WHERE user_id = ?
    `;

    // Run both queries in parallel.
    Promise.all([
        new Promise((resolve, reject) => db.all(topPlayersSql, [], (err, rows) => err ? reject(err) : resolve(rows))),
        new Promise((resolve, reject) => db.get(currentUserRankSql, [userId], (err, row) => err ? reject(err) : resolve(row)))
    ]).then(([topPlayers, currentUserRank]) => {
        res.json({
            topPlayers: topPlayers,
            currentUserRank: currentUserRank || null
        });
    }).catch(err => {
        console.error("Error fetching combined leaderboard data:", err.message);
        res.status(500).send('Server error fetching leaderboard.');
    });
});

module.exports = router;