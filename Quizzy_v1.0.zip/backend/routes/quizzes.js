// backend/routes/quizzes.js

const express = require('express');
const db = require('../database');
const auth = require('../middleware/auth');
const router = express.Router();

// GET /api/quizzes/topics - Fetches all available quiz topics with correct question counts.
router.get('/topics', auth, (req, res) => {
    const sql = `
        SELECT 
            t.id, 
            t.name, 
            t.description, 
            COUNT(q.id) as questionCount 
        FROM topics t 
        LEFT JOIN questions q ON t.id = q.topic_id 
        GROUP BY t.id, t.name, t.description
        ORDER BY t.name ASC
    `;
    db.all(sql, [], (err, rows) => {
        if (err) {
            console.error("Error fetching topics with counts:", err.message);
            return res.status(500).send('Server error fetching topics.');
        }
        const topics = rows.map(row => ({
            _id: row.id,
            name: row.name,
            description: row.description,
            questionCount: row.questionCount
        }));
        res.json(topics);
    });
});

// POST /api/quizzes/start - Now returns topic name along with questions.
router.post('/start', auth, (req, res) => {
    const { topicId } = req.body;
    const userId = req.user.id;

    db.serialize(() => {
        db.get(`SELECT name FROM topics WHERE id = ?`, [topicId], (err, topic) => {
            if (err || !topic) return res.status(404).send('Topic not found.');

            const questionsSql = `SELECT id, text, options FROM questions WHERE topic_id = ?`;
            db.all(questionsSql, [topicId], (err, questions) => {
                if (err || questions.length === 0) return res.status(404).send('No questions found for this topic.');

                const formattedQuestions = questions.map(q => ({ _id: q.id, text: q.text, options: JSON.parse(q.options) }));
                const sessionSql = `INSERT INTO quiz_sessions (user_id, topic_id, score, totalQuestions, answers) VALUES (?, ?, ?, ?, ?)`;
                
                db.run(sessionSql, [userId, topicId, -1, questions.length, '{}'], function(err) {
                    if (err) return res.status(500).send('Error creating quiz session.');
                    
                    res.status(201).json({
                        _id: this.lastID,
                        topicName: topic.name,
                        questions: formattedQuestions
                    });
                });
            });
        });
    });
});

// POST /api/quizzes/submit - Calculates score for a database quiz.
router.post('/submit', auth, (req, res) => {
    const { sessionId, answers } = req.body;
    const userId = req.user.id;
    db.get(`SELECT * FROM quiz_sessions WHERE id = ? AND user_id = ?`, [sessionId, userId], (err, session) => {
        if (err || !session) return res.status(404).send('Session not found.');
        db.all(`SELECT id, correctOption FROM questions WHERE topic_id = ?`, [session.topic_id], (err, correct) => {
            let score = 0;
            const correctMap = new Map(correct.map(q => [q.id.toString(), q.correctOption]));
            for (const qId in answers) {
                if (correctMap.get(qId) === answers[qId]) score++;
            }
            db.run(`UPDATE quiz_sessions SET score = ?, answers = ? WHERE id = ?`, [score, JSON.stringify(answers), sessionId], (err) => {
                if (err) return res.status(500).send('Error saving score.');
                res.json({ sessionId: sessionId, score: score });
            });
        });
    });
});

// GET /api/quizzes/results/:sessionId - Fetches detailed results.
router.get('/results/:sessionId', auth, (req, res) => {
    const { sessionId } = req.params;
    const userId = req.user.id;
    const sql = `SELECT * FROM quiz_sessions WHERE id = ? AND user_id = ?`;
    db.get(sql, [sessionId, userId], (err, session) => {
        if (err || !session) return res.status(404).send('Results not found.');
        db.all(`SELECT id, text, options, correctOption FROM questions WHERE topic_id = ?`, [session.topic_id], (err, questions) => {
            const userAnswers = JSON.parse(session.answers);
            const details = questions.map(q => ({
                question: { _id: q.id, text: q.text, options: JSON.parse(q.options), correctOption: q.correctOption },
                userAnswer: userAnswers[q.id]
            }));
            res.json({ score: session.score, totalQuestions: session.totalQuestions, details, topicId: session.topic_id });
        });
    });
});

// GET /api/quizzes/history - Fetches the user's quiz history.
router.get('/history', auth, (req, res) => {
    const userId = req.user.id;
    const sql = `
        SELECT 
            s.id, s.score, s.totalQuestions, s.createdAt, t.name as topicName 
        FROM quiz_sessions s 
        LEFT JOIN topics t ON s.topic_id = t.id 
        WHERE s.user_id = ? AND s.score != -1 
        ORDER BY s.createdAt DESC
    `;
    db.all(sql, [userId], (err, rows) => {
        if (err) return res.status(500).send('Server error fetching history.');
        const history = rows.map(r => ({ _id: r.id, score: r.score, totalQuestions: r.totalQuestions, createdAt: r.createdAt, topic: { name: r.topicName || 'Archived Topic' } }));
        res.json(history);
    });
});

// POST /api/quizzes/save-generated - Saves results from an AI-generated quiz.
router.post('/save-generated', auth, (req, res) => {
    const { topicName, score, totalQuestions } = req.body;
    const userId = req.user.id;
    const genericTopicName = "AI Generated Quiz";

    db.serialize(() => {
        db.get(`SELECT id FROM topics WHERE name = ?`, [genericTopicName], (err, topic) => {
            if (err) return res.status(500).send('Server error finding topic.');
            const saveSession = (topicId) => {
                const answersJson = JSON.stringify({ "actualTopic": topicName });
                const sql = `INSERT INTO quiz_sessions (user_id, topic_id, score, totalQuestions, answers) VALUES (?, ?, ?, ?, ?)`;
                db.run(sql, [userId, topicId, score, totalQuestions, answersJson], function(err) {
                    if (err) return res.status(500).send('Error saving quiz session.');
                    res.status(201).json({ message: "AI quiz result saved successfully." });
                });
            };
            if (topic) {
                saveSession(topic.id);
            } else {
                db.run(`INSERT INTO topics (name, description) VALUES (?, ?)`, [genericTopicName, "Results from quizzes generated by the AI."], function(err) {
                    if (err) return res.status(500).send('Error creating generic topic.');
                    saveSession(this.lastID);
                });
            }
        });
    });
});

module.exports = router;