// backend/routes/admin.js

const express = require('express');
const db = require('../database');
const auth = require('../middleware/auth');
const router = express.Router();

// --- PUBLIC LOGGING ROUTE ---
router.post('/log-event', auth, (req, res) => {
    const userId = req.user.id;
    const { featureUsed, topicPrompt } = req.body;
    if (!featureUsed || !topicPrompt) return res.status(400).send('Missing required log data.');
    const sql = `INSERT INTO ai_generation_log (user_id, feature_used, topic_prompt) VALUES (?, ?, ?)`;
    db.run(sql, [userId, featureUsed, topicPrompt], (err) => {
        if (err) return res.status(500).send('Server error saving log event.');
        res.status(201).send('Log event saved.');
    });
});


// --- ADMIN-ONLY ROUTES ---
const adminAuth = (req, res, next) => {
    if (req.user.role !== 'admin') {
        return res.status(403).send('Access denied. Administrator privileges required.');
    }
    next();
};
router.use(auth, adminAuth);

// GET /api/admin/stats
router.get('/stats', (req, res) => {
    const userCountSql = `SELECT COUNT(*) as totalUsers FROM users`;
    const quizCountSql = `SELECT COUNT(*) as totalQuizzes FROM quiz_sessions WHERE score != -1`;
    const topicCountSql = `SELECT COUNT(*) as totalTopics FROM topics`;
    const endlessRunsCountSql = `SELECT COUNT(DISTINCT user_id) as totalEndlessRuns FROM cumulative_leaderboard`;

    Promise.all([
        new Promise((resolve, reject) => db.get(userCountSql, (err, row) => err ? reject(err) : resolve(row.totalUsers))),
        new Promise((resolve, reject) => db.get(quizCountSql, (err, row) => err ? reject(err) : resolve(row.totalQuizzes))),
        new Promise((resolve, reject) => db.get(topicCountSql, (err, row) => err ? reject(err) : resolve(row.totalTopics))),
        new Promise((resolve, reject) => db.get(endlessRunsCountSql, (err, row) => err ? reject(err) : resolve(row.totalEndlessRuns))),
    ]).then(([totalUsers, totalQuizzes, totalTopics, totalEndlessRuns]) => {
        res.json({ totalUsers, totalQuizzes, totalTopics, totalEndlessRuns });
    }).catch(err => res.status(500).send('Server error fetching stats.'));
});

// GET /api/admin/users & Block/Unblock routes
router.get('/users', (req, res) => {
    db.all(`SELECT id, name, email, isBlocked FROM users WHERE role = 'user'`, (err, rows) => {
        if (err) return res.status(500).send('Server error fetching users.');
        res.json(rows.map(r => ({ ...r, _id: r.id })));
    });
});
router.post('/users/:id/block', (req, res) => {
    db.run(`UPDATE users SET isBlocked = 1 WHERE id = ?`, [req.params.id], function(err) {
        if (err || this.changes === 0) return res.status(404).send('User not found.');
        res.send('User blocked successfully.');
    });
});
router.post('/users/:id/unblock', (req, res) => {
    db.run(`UPDATE users SET isBlocked = 0 WHERE id = ?`, [req.params.id], function(err) {
        if (err || this.changes === 0) return res.status(404).send('User not found.');
        res.send('User unblocked successfully.');
    });
});

// GET /api/admin/logs
router.get('/logs', (req, res) => {
    const sql = `SELECT l.id, u.name as userName, l.feature_used, l.topic_prompt, l.createdAt FROM ai_generation_log l JOIN users u ON l.user_id = u.id ORDER BY l.createdAt DESC LIMIT 100`;
    db.all(sql, [], (err, rows) => {
        if (err) return res.status(500).send('Server error fetching logs.');
        res.json(rows);
    });
});

// Leaderboard Management routes
router.get('/leaderboard', (req, res) => {
    const sql = `SELECT u.id as userId, u.name as userName, cl.total_score, cl.total_questions_answered, cl.last_played_at FROM cumulative_leaderboard cl JOIN users u ON cl.user_id = u.id ORDER BY cl.total_score DESC`;
    db.all(sql, [], (err, rows) => {
        if (err) return res.status(500).send('Server error fetching leaderboard.');
        res.json(rows);
    });
});
router.post('/leaderboard/reset/:userId', (req, res) => {
    const { userId } = req.params;
    const sql = `UPDATE cumulative_leaderboard SET total_score = 0, total_questions_answered = 0 WHERE user_id = ?`;
    db.run(sql, [userId], function(err) {
        if (err) return res.status(500).send('Server error resetting score.');
        if (this.changes === 0) return res.status(404).send('User not found on the leaderboard.');
        res.send('User score reset to zero successfully.');
    });
});

// --- TOPIC & QUESTION MANAGEMENT ---

// GET /api/admin/topics
router.get('/topics', (req, res) => {
    const sql = `
        SELECT t.id, t.name, t.description, COUNT(q.id) as questionCount
        FROM topics t
        LEFT JOIN questions q ON t.id = q.topic_id
        GROUP BY t.id, t.name, t.description
        ORDER BY t.name ASC
    `;
    db.all(sql, [], (err, rows) => {
        if (err) {
            console.error("Error fetching admin topics:", err.message);
            return res.status(500).send('Server error fetching topics.');
        }
        res.json(rows);
    });
});

// POST /api/admin/topics
router.post('/topics', (req, res) => {
    const { name, description } = req.body;
    if (!name) return res.status(400).send('Topic name is required.');
    const sql = `INSERT INTO topics (name, description) VALUES (?, ?)`;
    db.run(sql, [name, description || ''], function (err) {
        if (err) {
            if (err.message.includes('UNIQUE constraint failed')) return res.status(400).send('A topic with this name already exists.');
            return res.status(500).send('Server error creating topic.');
        }
        res.status(201).json({ id: this.lastID, name, description });
    });
});

// GET /api/admin/topics/:topicId/questions
router.get('/topics/:topicId/questions', (req, res) => {
    const { topicId } = req.params;
    const sql = `SELECT * FROM questions WHERE topic_id = ? ORDER BY id DESC`;
    db.all(sql, [topicId], (err, rows) => {
        if (err) return res.status(500).send('Server error fetching questions.');
        const questions = rows.map(q => ({ ...q, options: JSON.parse(q.options) }));
        res.json(questions);
    });
});

// POST /api/admin/questions
router.post('/questions', (req, res) => {
    const { topicId, text, options, correctOption, difficulty } = req.body;
    if (!topicId || !text || !options || correctOption === undefined || !difficulty) return res.status(400).send('All question fields are required.');
    if (!Array.isArray(options) || options.length !== 4) return res.status(400).send('There must be exactly 4 options provided as an array.');
    if (correctOption < 0 || correctOption > 3) return res.status(400).send('correctOption must be an index between 0 and 3.');
    const optionsJson = JSON.stringify(options);
    const sql = `INSERT INTO questions (topic_id, text, options, correctOption, difficulty) VALUES (?, ?, ?, ?, ?)`;
    db.run(sql, [topicId, text, optionsJson, correctOption, difficulty], function(err) {
        if (err) return res.status(500).send('Server error adding question.');
        res.status(201).json({ id: this.lastID });
    });
});

module.exports = router;