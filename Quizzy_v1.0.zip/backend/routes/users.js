// backend/routes/users.js

const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../database');
const router = express.Router();

// Route: POST /api/users/register
router.post('/register', async (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).send('Name, email, and password are required.');
    }

    try {
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const sql = `INSERT INTO users (name, email, password) VALUES (?, ?, ?)`;
        db.run(sql, [name, email, hashedPassword], function (err) {
            if (err) {
                if (err.message.includes('UNIQUE constraint failed')) {
                    return res.status(400).send('An account with this email already exists.');
                }
                return res.status(500).send('Server error creating user.');
            }
            res.status(201).json({ id: this.lastID, name, email });
        });
    } catch (error) {
        res.status(500).send('Server error during registration.');
    }
});

module.exports = router;