// backend/middleware/auth.js

const jwt = require('jsonwebtoken');

function authMiddleware(req, res, next) {
    // Get the token from the request header
    const token = req.header('x-auth-token');

    // Check if no token is provided
    if (!token) {
        return res.status(401).send('Access denied. No token provided.');
    }

    try {
        // Verify the token using the secret key
        const decodedPayload = jwt.verify(token, process.env.JWT_SECRET_KEY);
        // Attach the user's information from the token to the request object
        req.user = decodedPayload;
        // Pass control to the next function in the chain (the route handler)
        next();
    } catch (ex) {
        res.status(400).send('Invalid token.');
    }
}

module.exports = authMiddleware;