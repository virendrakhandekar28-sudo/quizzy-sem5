// backend/database.js

const sqlite3 = require('sqlite3').verbose();

// This connects to the 'quizzy.db' file in the same directory.
const db = new sqlite3.Database('./quizzy.db', (err) => {
  if (err) {
    console.error("Error opening database: " + err.message);
  } else {
    // Enable foreign key support for SQLite
    db.run('PRAGMA foreign_keys = ON;', (err) => {
      if (err) {
        console.error("Could not enable foreign keys:", err);
      }
    });
    console.log("Connected to the SQLite database.");
  }
});

module.exports = db;