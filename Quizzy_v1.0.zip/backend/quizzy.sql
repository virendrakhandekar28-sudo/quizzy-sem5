-- Quizzy Web-Based Quiz Platform - SQLite Schema
-- This script creates all the necessary tables for the application.
-- Execute this script to initialize a new 'quizzy.db' file.

-- PRAGMA foreign_keys = ON; -- It's good practice to enable foreign key constraints.

-- -----------------------------------------------------
-- Table `users`
-- Stores user account information, roles, and status.
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INTEGER PRIMARY KEY AUTOINCREMENT,
  `name` TEXT NOT NULL,
  `email` TEXT NOT NULL UNIQUE,
  `password` TEXT NOT NULL, -- Should store a hashed password, not plain text
  `role` TEXT NOT NULL DEFAULT 'user', -- Can be 'user' or 'admin'
  `isBlocked` BOOLEAN NOT NULL DEFAULT 0, -- 0 for false, 1 for true
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);


-- -----------------------------------------------------
-- Table `topics`
-- Stores the different quiz topics available.
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `topics` (
  `id` INTEGER PRIMARY KEY AUTOINCREMENT,
  `name` TEXT NOT NULL UNIQUE,
  `description` TEXT,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);


-- -----------------------------------------------------
-- Table `questions`
-- Stores all quiz questions, linked to a specific topic.
-- The 'options' field will store a JSON array as a string.
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `questions` (
  `id` INTEGER PRIMARY KEY AUTOINCREMENT,
  `topic_id` INTEGER NOT NULL,
  `text` TEXT NOT NULL,
  `options` TEXT NOT NULL, -- Stored as a JSON string, e.g., '["Option A", "Option B", "Option C"]'
  `correctOption` INTEGER NOT NULL, -- 0-based index corresponding to the 'options' array
  `difficulty` TEXT NOT NULL DEFAULT 'Medium', -- 'Easy', 'Medium', 'Hard'
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`) ON DELETE CASCADE
);


-- -----------------------------------------------------
-- Table `quiz_sessions`
-- Records each quiz attempt by a user, storing their answers and score.
-- The 'answers' field will store a JSON object mapping question IDs to the user's selected option index.
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `quiz_sessions` (
  `id` INTEGER PRIMARY KEY AUTOINCREMENT,
  `user_id` INTEGER NOT NULL,
  `topic_id` INTEGER NOT NULL,
  `score` INTEGER NOT NULL,
  `totalQuestions` INTEGER NOT NULL,
  `answers` TEXT NOT NULL, -- Stored as a JSON string, e.g., '{"questionId1": 2, "questionId2": 0}'
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`) ON DELETE CASCADE
);